#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/pio.h"
#include "ring_buffer.h"
#include "check_point.h"

void set_user_send_request(void);
extern bool user_rec_ready_flag;
extern bool user_send_request_flag;


// call from main loop @PICO_Pic_colo.c

#define BUFF_SIZE 2100
struct RING_BUFF user_receive_ring_buff;   // extern reference in uart.c
char user_receive_buff[BUFF_SIZE];
struct RING_BUFF user_send_ring_buff;  // extern reference in uart.c
char user_send_buff[BUFF_SIZE];

void start_user_operation(void);  // define in this file
void set_user_send_request(void);
extern bool sec_flag;
void uart_set_user_request(void); 

char large_buff[1024];

// call from main_init() @PICO_Pic_colo.c
void custom_init(void)
{
    init_ring_buff( &user_receive_ring_buff, user_receive_buff, BUFF_SIZE );
    init_ring_buff( &user_send_ring_buff, user_send_buff,BUFF_SIZE );

    set_cp_pass(0);  // Set Pass mode
    set_cp_hold(1);  // Set Auto( release)
    set_cp_hold(2);
    set_cp_hold(3);
    set_cp_auto(4);
    set_cp_hold(5);  // Set Hold mode

    set_cp_sub_sec_clear(0);  // Set sub_sec_clear mode
    set_cp_manual_clear(1);  // Set manual_clear_mode
    set_cp_manual_clear(2);
    set_cp_manual_clear(3);
    set_cp_manual_clear(4);
    set_cp_manual_clear(5);  // Set Hold mode

large_buff[0] = 'A';
large_buff[1023] = 'B';

}

// call from uart send/receive loop
// short means less than 50us
void custom_short_ope(void)
{

    return;
}


// call from main_loop() @PICO_Pic_colo.c
// so, call is stop when uart send/receive looping
void custom_main() {
    char c;
    check_point(0);
    custom_short_ope();

    if( user_rec_ready_flag )
    {
        while( user_receive_ring_buff.flag == BUFF_NOT_EMPTY )
        {
            c = get_ring_buff( &user_receive_ring_buff );
            put_ring_buff( &user_send_ring_buff, c);
        }
        user_send_request_flag = true;
        user_rec_ready_flag = false;
        check_point(1);
        check_point(2);
        check_point(3);
        check_point(4);
        check_point(5);
    }
}
