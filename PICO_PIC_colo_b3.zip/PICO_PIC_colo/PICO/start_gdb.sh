#!/bin/bash
gdb-multiarch PICO_PIC_colo.elf
