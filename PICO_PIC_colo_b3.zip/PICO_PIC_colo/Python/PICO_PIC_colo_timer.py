#!/usr/bin/env python
#-*-:utf-8

import time

ten_ms_time = 0
sub_sec_time = 0
sec_time = 0
ten_ms_flag = False
sub_sec_flag = False
sec_flag = False
sub_sec_count = 0
send_time = 0
send_timing_flag = False
sub_sec_loop_count = 0
show_cp_timing =False

def init():
    global ten_ms_time
    global sub_sec_time
    global sec_time
    global ten_ms_flag
    global sub_sec_flag
    global sec_flag
    global sub_sec_count
    global send_time
    global send_timing_flag
    global sub_sec_loop_count
    global show_cp_timing

    current_time = time.time()
    ten_ms_time = current_time+0.01
    sub_sec_time = current_time+0.1
    sec_time = current_time+1
    sec_flag = False
    sub_sec_flag = False
    ten_ms_flag = False
    sub_sec_count = 0
    send_timing_flag = False
    send_time  = sub_sec_time
    sub_sec_loop_count = 0


def main():
    global ten_ms_time
    global sub_sec_time
    global sec_time
    global ten_ms_flag
    global sub_sec_flag
    global sec_flag
    global sub_sec_count
    global send_time
    global send_timing_flag
    global sub_sec_loop_count

    sec_flag = False
    sub_sec_flag = False
    ten_ms_flag = False

    current_time = time.time()
    if ten_ms_time <= current_time :
        ten_ms_flag = True;
        ten_ms_time += 0.01

    if sub_sec_time <= current_time :
        sub_sec_count += 1
        if sub_sec_count>= 10 :
            sub_sec_count = 0
        sub_sec_flag = True;
        sub_sec_time += 0.1
        sub_sec_loop_count += 1

    if sec_time <= current_time :
        sec_flag = True;
        sec_time += 1

    if send_time <= current_time :
        send_timing_flag = True;
        send_time  += 0.1

    # current_time = time.time()
    # if ten_ms_time <= current_time :
    #     ten_ms_flag = True;
    #     ten_ms_time += 0.01

    # if sub_sec_time <= current_time :
    #     sub_sec_count += 1
    #     if sub_sec_count>= 10 :
    #         sub_sec_count = 0
    #     sub_sec_flag = True;
    #     sub_sec_time += 0.1

    # if sec_time <= current_time :
    #     sec_flag = True;
    #     sec_time += 1

    # if send_time <= current_time :
    #     send_timing_flag = True;
    #     send_time  += 0.1

def set_send_time( next_step ):
    global send_time
    global send_timing_flag
    send_time = time.time() + next_step
    send_timing_flag = False;

def get_time_str():
    current_time = time.time()
    return str(current_time)

def tick( s ):
    print( s+' '+get_time_str() )


