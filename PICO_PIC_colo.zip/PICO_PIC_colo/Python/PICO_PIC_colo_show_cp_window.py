#!/usr/bin/env python
#-*-:utf-8

import PySimpleGUI as sg
import PICO_PIC_colo_comm as comm
import PICO_PIC_colo_analyze as analyze
import PICO_PIC_colo_pickle as pickle_dict

show_cp_window = sg.Window('')
show_cp_flag = False
var_break_point = [' ',' ',' ',' ']
var_hold_mode = [' ',' ',' ',' ']
var_pass_count = [' ',' ',' ',' ']

def create_cp_block( cp ):
    val_key='_Val_cp_'+cp+'_'
    mode_key='_Mode_cp_'+cp+'_'
    break_key='_Break_cp_'+cp+'_'
    cp_name='<'+cp+'>'
    return sg.Column([[ sg.Text( cp_name,size=(4,1))],
                      [ sg.Text('Valu',key=val_key,size=(4,1),justification='right')],
                      [ sg.Text('Pass',size=(4,1) ,key=mode_key,enable_events=True)],
                      [ sg.Text('<B>',size=(3,1),key=break_key,enable_events=True)]])

def create_window( window_parameter):
    global show_cp_window
    global show_cp_flag

    x = window_parameter[0]
    y = window_parameter[1]
    param = window_parameter[2]

    show_cp_layout = [
        [sg.Text('Check Point')],
        [ create_cp_block( '00' ),
         create_cp_block( '01' ),
         create_cp_block( '02' ),
         create_cp_block( '03' ),
         create_cp_block( '04' ),
         create_cp_block( '05' ),
         create_cp_block( '06' ),
         create_cp_block( '07' ),
         create_cp_block( '08' ),
         create_cp_block( '09' ),
         create_cp_block( '10' ),
         create_cp_block( '11' ),
         create_cp_block( '12' ),
         create_cp_block( '13' ),
         create_cp_block( '14' ),
         create_cp_block( '15' ),
         sg.Button('Release')]
     ]

    show_cp_window = sg.Window('Show check point', show_cp_layout,location=(x,y),**param)
    show_cp_window.hide()
    show_cp_flag = False

    return

break_posi = 16

def update_cp( hold, pass_count, b_p ):

    for cp in range(0,16):
        if cp<=9 : cp_str = '0'+str(cp)
        else : cp_str = str(cp)

        val_key='_Val_cp_'+cp_str+'_'
        mode_key='_Mode_cp_'+cp_str+'_'
        break_key='_Break_cp_'+cp_str+'_'
        count_str = str(pass_count[cp])

        show_cp_window[ val_key ].update( count_str )
        if hold[cp] == 0:
            show_cp_window[ mode_key ].update( 'Pass',text_color='#ffffff')
        elif hold[cp] == 1:
            show_cp_window[ mode_key ].update( 'Hold',text_color='#ff0000')
        elif hold[cp] == 2:
            show_cp_window[ mode_key ].update( 'Auto')
        else: 
            show_cp_window[ mode_key ].update( 'Else' )
        if cp == b_p :
            show_cp_window[ break_key ].update( '<B>' )
        else :
            show_cp_window[ break_key ].update( '   ' )

def show_window():
    global show_cp_flag
    global var_break_point
    global var_hold_mode
    global var_pass_count

    var_break_point = pickle_dict.get_dict( 'break_point' )
    var_hold_mode = pickle_dict.get_dict( 'hold_mode' )
    var_pass_count = pickle_dict.get_dict( 'pass_count' )

    show_cp_window.UnHide()
    show_cp_flag = True
    return

# 0:Pass 1:Hold 2:Auto

def show_cp_mode_operation( e ):
    mode_str = show_cp_window[ e ].get()

    if mode_str == 'Auto ':
        show_cp_window[ e ].update( 'Hold ',text_color='#ff0000')
    elif mode_str == 'Hold ':
        show_cp_window[ e ].update( 'Pass ',text_color='#ffffff')
    elif mode_str == 'Pass ':
        show_cp_window[ e ].update( 'Auto ')
    else: 
        show_cp_window[ e ].update( 'ELSE ')

def get_break_point():
    global var_break_point
    comm_str = 'R '+var_break_point[1]+' '+var_break_point[2]
    comm.debugger_send( comm_str )
    comm.wait_until_receive_response()
    receive_str = comm.debugger_receive()
    if receive_str != None: 
        return receive_str.split(' ')
    else :
        return []

def get_hold_mode():
    comm_str = 'R '+var_hold_mode[1]+' '+var_hold_mode[2]
    comm.debugger_send( comm_str )
    comm.wait_until_receive_response()
    receive_str = comm.debugger_receive()
    if receive_str != None: 
        return receive_str.split(' ')
    else :
        return []

def get_pass_count():
    comm_str = 'R '+var_pass_count[1]+' '+var_pass_count[2]
    comm.debugger_send( comm_str )
    comm.wait_until_receive_response()
    receive_str = comm.debugger_receive()
    if receive_str != None: 
        return receive_str.split(' ')
    else :
        return []

def release_break():
    comm.debugger_send( 'B R ' )
    comm.wait_until_receive_response()
    receive_str = comm.debugger_receive()
    if receive_str != None: 
        return receive_str.split(' ')
    else :
        return []

def convert_int(s):
    try:
        int(s, 10)
    except ValueError:
        return -1
    else:
        return int(s, 10)

def convert_hex2_to_dec( hex2 ):
    return int(hex2,16)


def convert_hex4_to_dec( hex4 ):
    le_str= hex4[2]+hex4[3]+hex4[0]+hex4[1]
    return int( le_str,16 )

def update_break_point():
    global break_posi
    res = get_break_point()
    if len(res)>=4 :
        break_posi = convert_hex2_to_dec( res[3] )
    else :
        break_point = 16

def update_hold_pass_count():
    global show_cp_flag
    global break_posi
    if show_cp_flag:
        hold_mode = []
        res = get_hold_mode()
        if len(res)>=4 :
            for posi in range(0,31,2):
                hold_mode.append( convert_hex2_to_dec( res[3][posi:posi+2] ) ) 
        else :
            hold_mode = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

        pass_count = []
        res = get_pass_count()
        if len(res)>=4 :
            for posi in range(0,63,4):
                pass_count.append( convert_hex4_to_dec( res[3][posi:posi+4] ) )
        else :
            pass_count = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
        
        update_cp( hold_mode, pass_count, break_posi)

def window_operation():
    global show_cp_flag
    if show_cp_flag:
        update_break_point()
        update_hold_pass_count()

        event, values = show_cp_window.read(timeout = 0)
        if event == 'Release':
            res_str = release_break()
        elif event == 'Interval':
            print( values['Interval'])
        elif event == 'Reset':
            print( 'event Reset' )
        elif '_Mode_cp_' in event:
            print( event )
        elif '_Disp_cp_' in event:
            print( event )
        elif event == 'Quit':
            show_cp_window.Hide()
            show_cp_flag = False
    return

def open_close():
    global show_cp_flag
    if show_cp_flag:
        show_cp_window.Hide()
        show_cp_flag = False
    else:
        show_window()
