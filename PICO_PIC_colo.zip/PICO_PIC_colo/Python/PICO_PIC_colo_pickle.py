import sys
import os
import pickle

PICO_GAP_dict = {}

def init_dict( file_path ):
    global PICO_GAP_dict
    if os.path.isfile( file_path ):
        f = open( file_path, mode='rb')
        PICO_GAP_dict = pickle.load(f)
        f.close()


def get_dict( key_str ):
    global PICO_GAP_dict
    return PICO_GAP_dict.get( key_str )

def put_dict( key_str, value):
    global PICO_GAP_dict
    PICO_GAP_dict[ key_str] = value

def save_dict( file_path ):
    global PICO_GAP_dict
    f = open( file_path, mode='wb')
    pickle.dump( PICO_GAP_dict,f )
    f.close()
