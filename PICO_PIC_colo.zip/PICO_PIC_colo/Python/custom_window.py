#!/usr/bin/env python
#-*-:utf-8

import PySimpleGUI as sg
import PICO_PIC_colo_comm as comm

window_flag = False
window = None

def create_window():
    global custom_flag
    global window
    layout =  [
                [sg.Text('<<Custom>>')],
                [ sg.Input('Input',key='-input text-')],
                [ sg.Button('Send')],
                [ sg.Input('Receive',key='-receive text-')],
                [ sg.Button('Hide Main'), sg.Button('Show Main')],
                [sg.Button('Quit')]
              ]
    window = sg.Window('Custom', layout,keep_on_top=True,size=(250, 250),finalize=True)
    window.hide()
    window_flag = False

def window_operation():
    global window_flag
    event, values = window.read(timeout = 0)

    if event == 'Send':
        input_str = window['-input text-'].get()
        comm.user_send( input_str)
        if comm.wait_until_user_response():
            receive_str = comm.user_receive()
            window['-receive text-'].update(receive_str)
        else :
            window['-receive text-'].update(r'Receive Error')
    elif event == 'Quit':
        window.Hide()
        window_flag = False
    return event

def show_window():
    global window_flag
    window.UnHide()
    window_flag = True

def main():
    loop = 0
    user_rec_str = comm.user_receive()


def open_close():
    global window_flag
    if window_flag:
        window.Hide()
        window_flag = False
    else:
        show_window()
