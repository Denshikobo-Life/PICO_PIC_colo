#!/usr/bin/env python
#-*-:utf-8

import serial
import PySimpleGUI as sg
import time

uartport = None

def open():
    global uartport
    uartport = serial.Serial(
#                port="/dev/ttyS0",
#                port="/dev/ttyACM0",
                port="COM4",
                baudrate=115200,
                bytesize=serial.EIGHTBITS,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                timeout=0)
    uartport.reset_input_buffer()
    uartport.reset_output_buffer()

def close():
    uartport.close()

def send_serial( send_str ):
    uartport.write(( send_str ).encode("utf-8") )

user_send_buffer= []
user_receive_buffer= []
debugger_send_buffer= []
debugger_receive_buffer= []
r_data = b''

def send_main():

    if len(debugger_send_buffer ) != 0 or len(user_send_buffer ) != 0:
        send_txt = '\x03'+'\x00'
        send_serial( send_txt )

    if len(debugger_send_buffer ) != 0:
        while len(debugger_send_buffer ) != 0:
            send_txt = '\x01'+debugger_send_buffer.pop(0)+'\x00'
            send_serial( send_txt )
            while uartport.writable == False:
                time.sleep(0.001)

    if len(user_send_buffer ) != 0:
        while len(user_send_buffer ) != 0:
            send_txt = '\x02'+user_send_buffer.pop(0)+'\x00'
            send_serial( send_txt )
            while uartport.writable == False:
                time.sleep(0.001)
    send_txt = '\x04'+'\x00'
    send_serial( send_txt )

def receive_main():
    global r_data
    r_c = uartport.read()
    r_data += r_c
    if r_c == b'\x00' :
        if len(r_data) >= 2:
            if r_data[0] == 1 and r_data[-1] == 0:
                debugger_receive_buffer.append( r_data.decode("utf-8")[1:-1])
            elif r_data[0] == 2 and r_data[-1] == 0:
                user_receive_buffer.append( r_data.decode("utf-8")[1:-1])
            elif r_data[0] == 3 and r_data[-1] == 0:
                print( r_data.decode("utf-8")[1:-1] )
        r_data = b''

def main():
    send_main();
    receive_main();

def user_send(s_text):
    user_send_buffer.append( s_text )
    send_main()
#    receive_main();

def user_receive():
    if len( user_receive_buffer ) != 0:
        return user_receive_buffer.pop(0)
    else : return ''

def wait_until_user_response():
    global r_data
    r_data = b''
    loop_count = 0
    while len( user_receive_buffer ) == 0:
        time.sleep(0.001)
        receive_main();
        loop_count+=1
        if loop_count > 2000: break
    if loop_count >= 2000:
        print('response time_out')
        return False
    return True

def check_send_buffer_clear():
    if len( debugger_send_buffer ) != 0:
        return False
    return True

def check_receive_buffer_clear():
    if len( debugger_receive_buffer ) != 0:
        return False
    return True

def debugger_send( s_text ):
    debugger_send_buffer.append( s_text )
    send_main()

def debugger_receive():
    if len( debugger_receive_buffer ) == 0 :
        return ' '
    return debugger_receive_buffer.pop(0)

def wait_until_receive_response():
    global r_data
    r_data = b''
    loop_count = 0
    while len( debugger_receive_buffer ) == 0:
        time.sleep(0.001)
        receive_main();
        loop_count+=1
        if loop_count > 2000: break
    if loop_count >= 2000:
        print('response time_out')
        return False
    return True
