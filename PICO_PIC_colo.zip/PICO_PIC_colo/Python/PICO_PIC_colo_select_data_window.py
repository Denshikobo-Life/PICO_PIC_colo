
#!/usr/bin/env python
#-*-:utf-8

import PySimpleGUI as sg
import PICO_PIC_colo_comm as comm
import PICO_PIC_colo_analyze as analyze
import PICO_PIC_colo_pickle as pickle_dict
import custom_window as custom
import time

select_data_flag = False
select_data_window = sg.Window('')
old_string = ''
select_var_list = []
disp_var_list = []
disp_var_list_update_flag =False

col_right = sg.Column([
          [ sg.Text('Search string'), sg.Input(size=(25, 1), enable_events=True, key='-INPUT-') ],
          [ sg.Listbox(  select_var_list, size=(40, 10) , key='-Select LIST-' ) ],
          [ sg.Button('Append'),sg.Text(' ',size=(20,1)), sg.Button('Reset') ]] )

def create_window( window_parameter ):
    global select_data_window
    global var_list
    global disp_var_list
    global select_var_list

    var_list = pickle_dict.get_dict( 'var_list')
    disp_var_list = pickle_dict.get_dict( 'disp_var_list')
    if( var_list == None ):
         var_list = []
    if( disp_var_list == None ):
         disp_var_list = []

    select_var_list = var_list

    x = window_parameter[0]
    y = window_parameter[1]
    param = window_parameter[2]

    select_data_layout = [
            [ sg.Text('Select DATA') ],
            [ col_right ]
        ]
    select_data_window = sg.Window('Select DATA', select_data_layout,location=(x,y),**param)
    select_data_flag = True
    return

def update_select_var_list():
    global select_var_list
    global var_list
    select_data_window['-Select LIST-'].update([])
    window_operation()
    time.sleep(0.5)
    var_list = pickle_dict.get_dict( 'var_list')
    select_var_list = var_list
    select_data_window['-Select LIST-'].update(select_var_list) 
    disp_var_list = []
    pickle_dict.put_dict( 'disp_var_list', disp_var_list )
    disp_var_list_update_flag = True


def show_window():
    global select_data_flag
    global var_list
    global select_var_list
    var_list = pickle_dict.get_dict( 'var_list')
    select_var_list = var_list

    select_data_window['-Select LIST-'].update(select_var_list) 
    select_data_window['-INPUT-'].update('')
    select_data_window.UnHide()
    select_data_flag = True
    return

def window_operation():
    global select_data_flag
    global old_string
    global disp_var_list
    global select_var_list
    global disp_var_list_update_flag
    if select_data_flag:
        event, values = select_data_window.read(timeout = 0)
        current_string = select_data_window['-INPUT-'].get()

        if current_string == '':
            old_string = ''
        elif  current_string != old_string:
            old_string = current_string
            select_var_list = []
            for x in var_list:
                if current_string in str(x):
                    select_var_list.append( x )
            select_data_window['-Select LIST-'].update(select_var_list)

        if event == 'Reset':
            select_data_window['-INPUT-'].update('')
            select_var_list = var_list
            select_data_window['-Select LIST-'].update(select_var_list)
            disp_var_list = []
            pickle_dict.put_dict( 'disp_var_list', disp_var_list )
            disp_var_list_update_flag = True
        elif event == 'Append':
            disp_var_list.extend(select_var_list)
            pickle_dict.put_dict( 'disp_var_list', disp_var_list )
            select_data_window['-INPUT-'].update('')
            disp_var_list_update_flag = True
        elif event == 'Quit':
            select_data_window.Hide()
            select_data_flag = False
    return

def open_close():
    global select_data_flag
    if select_data_flag:
        select_data_window.Hide()
        select_data_flag = False
    else:
        show_window()
