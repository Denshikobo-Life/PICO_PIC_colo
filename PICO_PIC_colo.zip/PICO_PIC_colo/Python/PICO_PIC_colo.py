#!/usr/bin/env python
#-*-:utf-8

import time
import PySimpleGUI as sg
import PICO_PIC_colo_comm as comm
import PICO_PIC_colo_analyze as analyze
import PICO_PIC_colo_pickle as pickle_dict
import custom_window as custom
import PICO_PIC_colo_select_data_window as select_data
import PICO_PIC_colo_show_data_window as show_data
import PICO_PIC_colo_choose_file_window as choose_file
import PICO_PIC_colo_show_cp_window as show_cp


def send_kill_command():
    print('Send Kill command')
    comm.debugger_send( 'K ' )
    if comm.wait_until_receive_response():
        receive_str = comm.debugger_receive()
        if receive_str != None: 
            return receive_str.split(' ')
        else :
            return [' ',' ',' ',' ']

pickle_dict.init_dict( './pickle_dict' )
check_flag = False

main_layout = [
            [sg.Column([[sg.Text('  ')]], size=(650,450))],
            [ sg.Button('Choose FILE'), sg.Button('Select DATA'), sg.Button('Show DATA'), sg.Button('Show CP'), sg.Button('Custom'),
             sg.Text(' ',size=(20,1)),sg.Text('time',key='_time_'),sg.Button('Quit')]
        ]

main_window = sg.Window('PICO_Pic_colo Main', main_layout,finalize=True)

main_flag = True
current_x,current_y = main_window.current_location()

show_data.create_window(current_x+10,current_y+40)
show_data.show_window()
select_data.create_window(current_x+360,current_y+40)
select_data.show_window()
show_cp.create_window(current_x+10,current_y+350)
choose_file.create_window(current_x+110,current_y+350)
custom.create_window()

comm.open()
current_time = time.time()

while True:             # Event Loop
    comm.main()
    prev_time = current_time
    current_time = time.time()
    elapse_time = current_time-prev_time;
    main_window['_time_'].update( str(elapse_time*1000) )
    event, values = main_window.read(timeout = 0)
    if event == sg.WIN_CLOSED:
        break
    elif event == 'Select DATA':
        select_data.open_close()
    elif event == 'Show DATA':
        show_data.open_close()
    elif event == 'Choose FILE':
        choose_file.open_close()
    elif event == 'Show CP':
        show_cp.open_close()
    elif event == 'Custom':
        custom.open_close()
    elif event == 'Quit':
        break

    choose_file.window_operation()
    select_data.window_operation()
    if select_data.disp_var_list_update_flag:
        show_data.update_disp_list()
        select_data.disp_var_list_update_flag = False
    show_cp.window_operation()
    show_data.window_operation()

    custom_return = custom.window_operation()
    if custom_return == 'Hide Main':
        main_window.Hide()
        main_flag = False
    elif custom_return == 'Show Main':
        main_window.UnHide()
        main_flag = True
    elif custom_return == 'Quit':
        if main_flag == False:
            break
    custom.main()

pickle_dict.save_dict( './pickle_dict' )

comm.close()

main_window.close()
