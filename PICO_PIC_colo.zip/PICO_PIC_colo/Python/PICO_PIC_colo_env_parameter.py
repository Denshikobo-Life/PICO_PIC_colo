import platform
from enum import Enum,auto

class Parameter_Set(Enum):
    WINDOWS = auto()
    RASPI = auto()
    OTHER = auto()
    CUSTOM1 = auto()
    CUSTOM2 = auto()

windows_set = []
raspberry_pi_set = []
default_set = []
custom1_set = []
custom2_set = []

def set_window_location( x,y ):
    global windows_set
    global raspberry_pi_set
    global default_set
    global custom1_set#wait_until_receive_flag = False

    global custom2_set

    windows_set = [
            [x+10,y+40, {'keep_on_top':True, 'no_titlebar':True, 'grab_anywhere':True, 'finalize':True}],
            [x+360,y+40, {'keep_on_top':True, 'no_titlebar':True, 'grab_anywhere':True, 'finalize':True}],
            [x+10,y+350, {'keep_on_top':True, 'no_titlebar':True, 'grab_anywhere':True, 'finalize':True,'element_padding':(0,0)}],
            [x+110,y+350, {'keep_on_top':True, 'no_titlebar':True, 'grab_anywhere':True, 'finalize':True}]
        ] 

    raspberry_pi_set = [
                [x+10,y+15, {'keep_on_top':True, 'no_titlebar':True, 'grab_anywhere':True, 'finalize':True}],
                [x+370,y+15, {'keep_on_top':True, 'no_titlebar':True, 'grab_anywhere':True, 'finalize':True}],
                [x+10,y+430, {'keep_on_top':True, 'no_titlebar':True, 'grab_anywhere':True, 'finalize':True,'element_padding':(0,0)}],
                [x,y-100, {'keep_on_top':True, 'no_titlebar':True, 'grab_anywhere':True, 'finalize':True}]
        ]

    default_set = windows_set
    custom1_set = [
            [],     #select_data
            [],     #show_data
            [],     #cp_window
            []      #file_chooser
        ]

    custom2_set = [
            [],     #select_data
            [],     #show_data
            [],     #cp_window
            []      #file_chooser
        ]

select_custom = None
#select_custom = Parameter_Set.CUSTOM1
#select_custom = Parameter_Set.CUSTOM2

def get_column_size():
    env_str = platform.system()
    if env_str == 'Linux' :
        return ( 660, 565 )
    elif env_str == 'Windows' :
        return ( 660, 450 )
    else :
        return ( 600, 450 )

def get_env_parameter():
    if select_custom == None :
        env_str = platform.system()
        if env_str == 'Linux' :
            return window_parameter( Parameter_Set.RASPI )
        elif env_str == 'windows' :
            return window_parameter( Parameter_Set.WINDOWS )
        else :
            return window_parameter( Parameter_Set.OTHER )
    else :
            return window_parameter( select_custom )

def window_parameter( sel ):

    if sel == Parameter_Set.RASPI:
        return raspberry_pi_set
    elif sel == Parameter_Set. WINDOWS:
        return windows_set
    elif sel == Parameter_Set.CUSTOM1:
        return custom1_set
    elif sel == Parameter_Set.CUSTOM2:
        return custom2_set
    elif sel == Parameter_Set.OTHER:
        return default_set
    else :
        return default_set
