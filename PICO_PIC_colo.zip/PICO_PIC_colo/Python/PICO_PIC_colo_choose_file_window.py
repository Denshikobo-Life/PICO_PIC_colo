#!/usr/bin/env python
#-*-:utf-8

import sys
import time
import PySimpleGUI as sg
import PICO_PIC_colo_comm as comm
import PICO_PIC_colo_analyze as analyze
import PICO_PIC_colo_pickle as pickle_dict

choose_file_window = sg.Window('')
choose_file_flag = False
elf_file_name = ''


def create_window(x,y):
    global choose_file_window
    global choose_file_flag
    global elf_file_name
    elf_file_name = pickle_dict.get_dict( 'elf_file_name')
    if( elf_file_name == None ):
        elf_file_name = ''

    choose_file_layout = [
            [sg.Text('Choose FILE')],
            [sg.Input( default_text=elf_file_name, key='-ELF FILE-')],
            [sg.Button('Select'), sg.Text(' ',size=(10,1)), sg.FileBrowse(file_types=(("ELF files", "*.elf"),))]
    ]
    choose_file_window = sg.Window('Choose File', choose_file_layout,keep_on_top=True,no_titlebar=True,grab_anywhere=True,location=(x,y),finalize=True)
    choose_file_window.hide()
    choose_file_flag = False
    return

def show_window():
    global choose_file_flag
    choose_file_window.UnHide()
    choose_file_flag = True
    return

def window_operation():
    global choose_file_flag
    global elf_file_name

    if choose_file_flag:
        event, values = choose_file_window.read(timeout = 0)
        if event == 'Select':
            elf_file_name =  choose_file_window['-ELF FILE-'].get()
            pickle_dict.put_dict( 'elf_file_name', elf_file_name )
            var_list = analyze.analyze_map( elf_file_name )
            pickle_dict.put_dict( 'var_list', var_list )

            for x in var_list:
                if 'break_point_num' in str(x):
                    pickle_dict.put_dict( 'break_point', x )
                if 'hold_mode' in str(x):
                    pickle_dict.put_dict( 'hold_mode', x )
                if 'pass_count' in str(x):
                    pickle_dict.put_dict( 'pass_count', x )

            choose_file_window.Hide()
            choose_file_flag = False
        elif event == 'Quit':
            choose_file_window.Hide()
            choose_file_flag = False

    return

def open_close():
    global choose_file_flag
    if choose_file_flag:
        choose_file_window.Hide()
        choose_file_flag = False
    else:
        show_window()
