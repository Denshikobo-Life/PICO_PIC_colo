
#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/uart.h"
#include "hardware/irq.h"
#include "ring_buffer.h"

#define BAUD_RATE 115200
#define DATA_BITS 8
#define STOP_BITS 1
#define PARITY    UART_PARITY_NONE

enum rec_mode {
  REC_IDLE,
  REC_DEBUG,
  REC_USER,
  REC_REQUEST,
  REC_RESET  
};

enum rec_mode uart_rec_mode;

bool command_send_request_flag;
bool user_send_request_flag;

bool command_rec_ready_flag;
bool user_rec_ready_flag;
bool receive_request_flag;

#define BUFF_SIZE 1024
struct RING_BUFF uart_send_ring_buff;
char uart_send_buff[BUFF_SIZE];
struct RING_BUFF uart_receive_ring_buff;
char uart_receive_buff[BUFF_SIZE];

extern struct RING_BUFF command_receive_ring_buff;
extern struct RING_BUFF command_send_ring_buff;
extern struct RING_BUFF user_receive_ring_buff;
extern struct RING_BUFF user_send_ring_buff;

void break_point( uint8_t bp );

void setup_uart()
{

    init_ring_buff( &uart_receive_ring_buff, uart_receive_buff, BUFF_SIZE );
    init_ring_buff( &uart_send_ring_buff, uart_send_buff,BUFF_SIZE );

    uart_rec_mode = REC_IDLE;

    command_send_request_flag = false;
    user_send_request_flag = false;
    command_rec_ready_flag = false;
    user_rec_ready_flag = false;
    receive_request_flag = false;
}

extern int pattern;
bool first_time = true;

void receive_char( void )
{
int r;
    r = getchar();
    put_ring_buff( &uart_receive_ring_buff, (char)r );
}

void send_char( char c )
{
    putchar( c );
}

void message_out( char c1, char c2 )
{
    send_char( (char)0x03 );
    send_char( c1 );
    send_char( c2 );
    send_char( (char)0x00 );
}

char convert_char( uint8_t h )
{
    if( h <= 9)return h+0x30;
    else return h - 10 + 'A';
}

void message_dump_hex( uint16_t d )
{
    uint8_t h;
    char c;
    send_char( (char)0x03 );

    h = (d>>12)&0x0f;
    c = convert_char( h );
    send_char( c );
    h = (d>>8)&0x0f;
    c = convert_char( h );
    send_char( c );
    h = (d>>4)&0x0f;
    c = convert_char( h );
    send_char( c );
    h = d&0x0f;
    c = convert_char( h );
    send_char( c );
    send_char( (char)0x00 );
}

void message_dump_buff( char *pointer )
{
    uint8_t loop;
    send_char( (char)0x03 );

    for( loop=0;loop<8;loop++)
      send_char( *pointer++ );
    send_char( (char)0x00 );
}

void uart_set_debugger_request(void) 
{
    char c;

    if( command_send_request_flag )
    {
        while( ( command_send_ring_buff.flag != BUFF_EMPTY )
            && ( uart_send_ring_buff.flag != BUFF_FULL) )
        {
            c = get_ring_buff( &command_send_ring_buff );
            put_ring_buff( &uart_send_ring_buff, c);
        }

        if(command_send_ring_buff.flag == BUFF_EMPTY)
        {
            command_send_request_flag = false;
        }
    }
}

void uart_set_user_request(void) 
{
    char c;
    if( user_send_request_flag )
    {
        while( ( user_send_ring_buff.flag != BUFF_EMPTY )
            && ( uart_send_ring_buff.flag != BUFF_FULL) )
        {
            c = get_ring_buff( &user_send_ring_buff );
            put_ring_buff( &uart_send_ring_buff, c);
        }

        if(user_send_ring_buff.flag == BUFF_EMPTY)
        {
            user_send_request_flag = false;
        }
    }
}

void uart_send_loop(void)
{
    char c;

    while( uart_send_ring_buff.flag != BUFF_EMPTY )
    {
        c = get_ring_buff( &uart_send_ring_buff );
        send_char( c );
    }
}

void uart_receive_loop(void) 
{
    char c;

    if( uart_receive_ring_buff.flag == BUFF_EMPTY )
        receive_char();

    while( uart_receive_ring_buff.flag != BUFF_EMPTY )
    {
        c = get_ring_buff( &uart_receive_ring_buff );
        switch( uart_rec_mode )
        {
        case REC_IDLE:
            if( c == 0x01 )
            {
                uart_rec_mode = REC_DEBUG;
                put_ring_buff( &command_receive_ring_buff, c);
            }
            else if( c == 0x02 )
            {
                uart_rec_mode = REC_USER;
                put_ring_buff( &user_receive_ring_buff, c);
            }
            else if( c == 0x03 )
            {
                uart_rec_mode = REC_REQUEST;
            }
            else if( c == 0x04 )
            {
                uart_rec_mode = REC_RESET;
            }
            break;
        case REC_DEBUG:
            put_ring_buff( &command_receive_ring_buff, c);
            if( c == 0x00 )
            {
                command_rec_ready_flag = true;
                uart_rec_mode = REC_IDLE;
            }
            break;
        case REC_USER:
            put_ring_buff( &user_receive_ring_buff, c);
            if( c == 0x00 )
            {
                user_rec_ready_flag = true;
                uart_rec_mode = REC_IDLE;
            }
            break;
        case REC_REQUEST:
            if( c == 0x00 )
            {
                receive_request_flag = true;
                uart_rec_mode = REC_IDLE;
            }
            break;
        case REC_RESET:
            if( c == 0x00 )
            {
                receive_request_flag = false;
                uart_rec_mode = REC_IDLE;
            }
            break;
        default:
            break;
        }

        if(  user_rec_ready_flag )
        {
            break;
        }

        if( command_rec_ready_flag) 
        {
            break;
        }
        receive_char();
    }
}

