#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/pio.h"
#include "pico/binary_info.h"
#include "pico/multicore.h"

const uint LED_PIN = 25;
void custom_init();
void custom_main();
void setup_uart(void);
void uart_main(void);
void command_response_init(void);
void command_response_main(void);
void release_break(void);
void reset_break_point(void);
//void set_ms_timer(void);
void start_ms_timer(void);
void ms_timer(void);

void clear_pass_count(void);
void reset_check_point(void);

bool kill_flag;
uint8_t sec_count;
extern uint16_t auto_release_count;
extern uint16_t pass_clear_count;

void main_init()
{
    stdio_init_all();

    setup_uart();
    command_response_init();
    reset_check_point();
    auto_release_count = 20;
    pass_clear_count = 10;

    custom_init();

    start_ms_timer();
    sec_count = 0;
    kill_flag = false;
}

extern volatile bool sec_flag;
void uart_send_loop(void);
void uart_receive_loop(void);

uint16_t main_loop_count;
uint16_t main_loop_hold_count;

void main_loop()
{
    ms_timer();
    if( sec_flag )
    {
        main_loop_hold_count = main_loop_count;
        main_loop_count = 0;
    }
    uart_send_loop();
    uart_receive_loop();
    command_response_main();
    custom_main();

    main_loop_count++;

    if( kill_flag )
    {
        sleep_ms(2000);
        *((int *)0xE000ED0C) = 0x05FA0004;
    }
}

int pattern;

void blink_n( int n )
{
    int loop;
    for (loop=0;loop<n;loop++ )
        {
            gpio_put(LED_PIN, 1);
            sleep_ms(50);
            gpio_put(LED_PIN, 0);
            sleep_ms(50);
        }
        sleep_ms(100);
}

void core1_entry() 
{
    gpio_init(LED_PIN);
    gpio_set_dir(LED_PIN, GPIO_OUT);
    pattern = 10;
    while (true) {
        if( pattern == 0 )
        {
            sleep_ms(250);
        }
        else if( pattern == 10 )
        {
            gpio_put(LED_PIN, 1);
            sleep_ms(250);
            gpio_put(LED_PIN, 0);
            sleep_ms(250);
        }
        else
        {
            blink_n( pattern );
            pattern = 0;
        }
    }
}

void reset_break_point(void);

int main() {
int r;
    main_init();
    multicore_launch_core1(core1_entry);

    while (true) {
        main_loop();
    }
    return 0;
}
