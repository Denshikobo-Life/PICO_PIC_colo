#include <stdio.h>
#include "pico/stdlib.h"

void reset_break_point(void);
void set_cp_auto( uint8_t cp);
void set_cp_hold( uint8_t cp);
void set_cp_pass( uint8_t cp);
void break_point( uint8_t bp );
void check_point(uint8_t cp);
void release_break(void);
