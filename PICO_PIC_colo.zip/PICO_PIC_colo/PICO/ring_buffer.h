
#include "pico/stdlib.h"

enum ring_buff_flag {
  BUFF_EMPTY,
  BUFF_NOT_EMPTY,
  BUFF_FULL,
  BUFF_ERROR  
};

struct RING_BUFF
{
    uint16_t read_posi;
    uint16_t write_posi;
    char *buff_pointer;
    uint16_t buff_size;
    enum ring_buff_flag flag;
};

void init_ring_buff( struct RING_BUFF *s, char *p_buff, uint size );
void put_ring_buff( struct RING_BUFF *s, char c );
char get_ring_buff( struct RING_BUFF *s );
void flush_ring_buff( struct RING_BUFF *s );
