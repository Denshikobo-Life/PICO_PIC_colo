#include <stdio.h>
#include "pico/stdlib.h"
#include "check_point.h"

uint16_t pass_count[16];
uint8_t hold_mode[16];        // 0:pass 1:hold 2:auto reset
uint8_t break_point_num;
bool release;

#define PASS_MODE 0
#define HOLD_MODE 1
#define AUTO_MODE 2

void clear_pass_count(void)
{
uint8_t loop;
    for(loop=0;loop<16;loop++)
    {
        pass_count[loop]=0;
    }
}

void reset_check_point(void)
{
    uint8_t loop;

    for(loop=0;loop<16;loop++)
    {
        pass_count[loop]=0;
        hold_mode[loop]=PASS_MODE;
    }
    break_point_num=16;
    release =false;
}

void command_response_main(void);
void ms_timer(void);
void uart_send_loop(void);
void uart_receive_loop(void);

extern uint16_t sub_ms_count;

void set_cp_auto( uint8_t cp)
{
    hold_mode[cp] = AUTO_MODE;
}

void set_cp_hold( uint8_t cp)
{
    hold_mode[cp] = HOLD_MODE;
}

void set_cp_pass( uint8_t cp)
{
    hold_mode[cp] = PASS_MODE;
}

uint16_t auto_loop_count;
uint16_t auto_release_count;
uint16_t pass_clear_count;
uint16_t break_point_timer;
uint16_t break_loop_count;
uint16_t break_sub_sec_count;
bool hold_flag;

extern bool sec_flag;
extern bool sub_sec_flag;
extern uint16_t sub_sec_count;
void break_point( uint8_t bp )
{
    pass_count[bp]++;
    if( pass_count[bp]>=30000)pass_count[bp]=30000;

    if( sub_sec_flag )
    {
        break_sub_sec_count++;
        if( break_sub_sec_count >= pass_clear_count )
        {
            clear_pass_count();
            break_sub_sec_count = 0;
        }
    }

    if( hold_mode[bp] == PASS_MODE )return;
    hold_flag = true;
    break_point_num = bp;
    if( hold_mode[bp]== AUTO_MODE )
    {
        auto_loop_count = 0;
        hold_flag = true;
        while( auto_loop_count < auto_release_count )
        {
            ms_timer();
            if( sub_sec_flag ) auto_loop_count++;
            uart_send_loop();
            uart_receive_loop();
            command_response_main();
            if( !hold_flag )break;
        }
    }
    else if( hold_mode[bp]== HOLD_MODE )
    {
        while( hold_flag )
        {
            ms_timer();
            uart_send_loop();
            uart_receive_loop();
            command_response_main();
        }
    }
    break_point_num = 16;
}

void check_point(uint8_t cp)
{
    break_point(cp);
}

void release_break(void)
{
    hold_flag = false;
}
