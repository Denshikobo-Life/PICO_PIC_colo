#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/uart.h"
#include "hardware/irq.h"
#include "ring_buffer.h"

void set_command_send_request(void);

#define BUFF_SIZE 1048
struct RING_BUFF command_receive_ring_buff;  // external reference in uart.c
char command_receive_buff[BUFF_SIZE];
struct RING_BUFF command_send_ring_buff; // external reference in uart.c
char command_send_buff[BUFF_SIZE];

enum mode {
    COMM_IDLE,
    COMM_READ,
    COMM_WRITE,
    COMM_BP,
    COMM_KILL,
    COMM_LOOPBACK,
    COMM_OTHER
};
enum mode comm_mode;

extern bool command_rec_ready_flag;
extern bool command_send_request_flag;
void release_break(void);

extern bool release;

void command_response_init(void)
{
    init_ring_buff( &command_receive_ring_buff, command_receive_buff, BUFF_SIZE );
    init_ring_buff( &command_send_ring_buff, command_send_buff, BUFF_SIZE );
    comm_mode = COMM_IDLE;
}

uint8_t hex_char_to_int( char c )
{
    if( c < '0')return (uint8_t)0x0ff;
    else if( c <= '9')return (uint8_t)(c - 48);
    else if( ( 'A' <= c )&&( c<='F')) return (uint8_t)(c - 55);
    else if( ( 'a' <= c )&&( c<='f')) return (uint8_t)(c - 87);
    else return (uint8_t)0xff;
}

uint dec_char_to_int(  char c )
{
    if( c < '0')return -1;
    else if( c <= '9')return c - 48;
    else return -1;
}

// 'hhhhhhhh'
char address_string[8];

uint convert_address ( struct RING_BUFF *ring_buff )
{
    uint address;
    uint loop;
    char c;

    address = 0;
    for( loop = 0; loop<8; loop++)
    {
        address <<= 4;
        c = get_ring_buff( ring_buff );
        address_string[loop] = c;
        address += (uint)hex_char_to_int( c );
    }
    return address;
}


// 'ddd '
char size_string[5];

uint convert_size ( struct RING_BUFF *ring_buff )
{
    uint size;
    uint loop;
    char c;

    size = 0;
    size_string[0] = '0';
    size_string[1] = ' ';

    if( ring_buff->flag == BUFF_EMPTY )return size;

    for( loop = 0; loop<4; loop++)
    {
        c = get_ring_buff( ring_buff );

        if( c == (char)0x00 )
        {
            size_string[loop] = ' ';
            return size;
        }
        size_string[loop] = c;
        if( c == ' ') return size;
        size *= 10;
        size += dec_char_to_int( c );
        if( ring_buff->flag == BUFF_EMPTY )
        {
            size_string[loop+1] = ' ';
            return size;
        }
    }
    size_string[4] = ' ';
    return size;
}

uint8_t convert_byte ( struct RING_BUFF *ring_buff )
{
    uint8_t byte;
    char c;

    c = get_ring_buff( ring_buff );
    if( c == ' ')
    {
        c = get_ring_buff( ring_buff );
    }
    byte = hex_char_to_int( c );
    byte <<=4;
    c = get_ring_buff( ring_buff );
    byte += hex_char_to_int( c );
    return byte;
}

char hex_to_hexchar( uint8_t h )
{
    if( h <= 9 ) return (char)(h+48);
    else return (char)(h+87);
}

void put_ring_buff_byte ( struct RING_BUFF *ring_buff, uint8_t byte )
{
    char c;
    uint8_t h;

    h = (byte>>4);
    h &= 0x0f;
    c = hex_to_hexchar( h );
    put_ring_buff( ring_buff, c);

    h = (byte & 0x0f);
    c = hex_to_hexchar( h );
    put_ring_buff( ring_buff, c);
}

void put_ring_buff_hex4 ( struct RING_BUFF *ring_buff, uint16_t hex4 )
{
    uint8_t h;

    h = (uint8_t)( (hex4>>8) & 0x0ff );
    put_ring_buff_byte ( ring_buff, h );

    h = (uint8_t)( hex4 & 0x0ff );
    put_ring_buff_byte ( ring_buff, h );
}

uint8_t get_ring_buff_byte ( struct RING_BUFF *ring_buff )
{
    char c;
    uint8_t h;

    c = get_ring_buff( ring_buff );
    h = hex_char_to_int( c );

    h <<=4;

    c = get_ring_buff( ring_buff );
    h += hex_char_to_int( c );

    return h;
}

void uart_set_debugger_request(void);

extern int pattern;
extern bool kill_flag;
void message_out( char c1, char c2 );
extern bool reset_request_flag;

extern uint16_t pass_count[16];
extern uint8_t hold_mode[16];        // 0:pass 1:hold 2:auto reset
extern uint8_t break_point_num;
extern bool sec_flag;

bool send_b_p = false;
bool send_p_c = false;
bool send_h_m = false;

char send_marker = '0';

void command_response_main(void)
{
    uint8_t *pointer;
    char c;
    uint address;
    uint size;
    uint loop;
    uint8_t byte;
    uint16_t hex4;

    while( command_rec_ready_flag )
    {
        switch( comm_mode )
        {
        case COMM_IDLE:
            c = get_ring_buff( &command_receive_ring_buff );
            // c = 0x01
            c = get_ring_buff( &command_receive_ring_buff );
            // c = 'W' or 'R' or else?
            if(c == 'R') comm_mode = COMM_READ;
            else if(c == 'W') comm_mode = COMM_WRITE;
            else if(c == 'B') comm_mode = COMM_BP;
            else if(c=='L') comm_mode = COMM_LOOPBACK;
            else if(c=='K') comm_mode = COMM_KILL;
            else comm_mode = COMM_OTHER;
            break;
        case COMM_READ:
            // hhhhhhhh
            c = get_ring_buff( &command_receive_ring_buff ); // ' '
            address = convert_address( &command_receive_ring_buff );
            c = get_ring_buff( &command_receive_ring_buff ); // ' '
            size = convert_size( &command_receive_ring_buff);

            // create response
            put_ring_buff( &command_send_ring_buff,(char)0x01 );
            put_ring_buff( &command_send_ring_buff,'r' );
            put_ring_buff( &command_send_ring_buff,' ' );

            // 'hhhhhhhh'
            for(loop=0;loop<8;loop++)
            {
                c = address_string[loop];
                put_ring_buff( &command_send_ring_buff, c );
            }

            put_ring_buff( &command_send_ring_buff, ' ' );
            for(loop=0;loop<4;loop++)
            {
                c = size_string[loop];
                put_ring_buff( &command_send_ring_buff, c );
                if(c== ' ')break;
            }
            if(c!= ' ') put_ring_buff( &command_send_ring_buff, ' ' );

            pointer = (uint8_t *)address;
            for( loop=0;loop<size;loop++ )
            {
                byte = *pointer;
                pointer++;
                put_ring_buff_byte( &command_send_ring_buff, byte );
            }
            put_ring_buff( &command_send_ring_buff, (char)0x00 );
            command_rec_ready_flag = false;
            command_send_request_flag = true;
            comm_mode = COMM_IDLE;
            break;
        case COMM_WRITE:
            //W hhhhhhhh d. hhhhhhh..
            // skip space
            c = get_ring_buff( &command_receive_ring_buff ); // ' '
            // get address
            address = convert_address( &command_receive_ring_buff );
            // skip space
            c = get_ring_buff( &command_receive_ring_buff ); // ' '
            // get size
            size = convert_size( &command_receive_ring_buff);

            // create response
            put_ring_buff( &command_send_ring_buff,(char)0x01 );
            put_ring_buff( &command_send_ring_buff,'w' );
            put_ring_buff( &command_send_ring_buff,' ' );

            // 'hhhhhhhh'
            for(loop=0;loop<8;loop++)
            {
                c = address_string[loop];
                put_ring_buff( &command_send_ring_buff, c );
            }

            put_ring_buff( &command_send_ring_buff, ' ' );
            for(loop=0;loop<4;loop++)
            {
                c = size_string[loop];
                put_ring_buff( &command_send_ring_buff, c );
                if(c== ' ')break;
            }
            if(c!= ' ')
            {
                put_ring_buff( &command_send_ring_buff, ' ' );
                // skip space
                c = get_ring_buff( &command_receive_ring_buff ); // ' '
            }

            pointer = (uint8_t *)address;
            for( loop=0;loop<size;loop++ )
            {
                byte = get_ring_buff_byte ( &command_receive_ring_buff );
                *pointer = byte;
                pointer++;
            }
            put_ring_buff( &command_send_ring_buff, (char)0x00 );
            flush_ring_buff( &command_receive_ring_buff );
            command_rec_ready_flag = false;
            command_send_request_flag = true;
            comm_mode = COMM_IDLE;
            break;
        case COMM_KILL:
            // create response common
            kill_flag = true;
            put_ring_buff( &command_send_ring_buff,(char)0x01 );
            put_ring_buff( &command_send_ring_buff,'k' );
            put_ring_buff( &command_send_ring_buff,' ' );
            put_ring_buff( &command_send_ring_buff, (char)0x00 );
            flush_ring_buff( &command_receive_ring_buff );
            // common response
            command_rec_ready_flag = false;
            command_send_request_flag = true;
            comm_mode = COMM_IDLE;
            break;
        case COMM_BP:
            // create response common
                put_ring_buff( &command_send_ring_buff,(char)0x01 );
                put_ring_buff( &command_send_ring_buff,'b' );
                put_ring_buff( &command_send_ring_buff,' ' );
            // skip space
            c = get_ring_buff( &command_receive_ring_buff ); // ' '
            // get 2nd LETTER
            c = get_ring_buff( &command_receive_ring_buff ); // 'B' or 'H' or 'P' or 'R'
            if( c=='R' )
            {
            // Release
                release = true;
                put_ring_buff( &command_send_ring_buff,'r' );
                put_ring_buff( &command_send_ring_buff,' ' );
            }

            flush_ring_buff( &command_receive_ring_buff );
            // common response
            put_ring_buff( &command_send_ring_buff, (char)0x00 );
            command_rec_ready_flag = false;
            command_send_request_flag = true;
            comm_mode = COMM_IDLE;
            break;
        case COMM_LOOPBACK:
            put_ring_buff( &command_send_ring_buff,'l' );
            while( command_receive_ring_buff.flag != BUFF_EMPTY )
            {
                c = get_ring_buff( &command_receive_ring_buff );
                put_ring_buff( &command_send_ring_buff, c );
            }
            command_send_request_flag = true;
            command_rec_ready_flag = false;
            comm_mode = COMM_IDLE;
            break;
        case COMM_OTHER:
            while( command_receive_ring_buff.flag != BUFF_EMPTY )
                (void)get_ring_buff( &command_receive_ring_buff );
            command_rec_ready_flag = false;
            comm_mode = COMM_IDLE;
            break;
        }
    }

// exec. per 0.1sec
    if( reset_request_flag )
    {
        reset_request_flag = false;

        put_ring_buff( &command_send_ring_buff,(char)0x01 );
        put_ring_buff( &command_send_ring_buff,'b' );
        put_ring_buff( &command_send_ring_buff,send_marker );
        put_ring_buff( &command_send_ring_buff,(char)0x00 );
        command_send_request_flag = true;
        send_marker++;
        if( send_marker > '9')send_marker = '0';

    }
}
