#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/timer.h"
#include "hardware/irq.h"

static uint64_t get_time(void) {
    // Reading low latches the high value
    uint32_t lo = timer_hw->timelr;
    uint32_t hi = timer_hw->timehr;
    return ((uint64_t) hi << 32u) | lo;
}

uint64_t current_time;
uint64_t ms_time;
uint64_t sub_sec_time;
uint64_t receive_time;
bool receive_timing_flag;
bool ms_flag;
bool sub_sec_flag;
uint16_t sub_sec_count;
bool sec_flag;
uint16_t ms_count;

void start_ms_timer(void)
{
    current_time = get_time();
    ms_time = current_time + 1000;
    sub_sec_time = current_time + 100000;
    ms_flag = false;
    ms_count = 0;
    sub_sec_flag = false;
    sub_sec_count = 0;
    sec_flag = false;
    receive_time = sub_sec_time;
    receive_timing_flag = false;
}

void ms_timer(void)
{
    sec_flag = false;
    sub_sec_flag = false;
    ms_flag = false;
    current_time = get_time();
    if( ms_time <= current_time )
    {
        ms_flag = true;
        ms_time = current_time + 1000;
        ms_count++;
    }

    if( sub_sec_time <= current_time )
    {
        sub_sec_flag = true;
        sub_sec_time +=  100000;
        sub_sec_count++;
        ms_count = 0;
        if( sub_sec_count >= 10 )
        {
            sec_flag = true;
            sub_sec_count = 0;
        }
    }

    if( receive_time <= current_time )
    {
        receive_timing_flag = true;
        receive_time +=  99000;
    }
}

void set_receive_time(void)
{
    receive_time = get_time() + 99000;
}

uint64_t prev_tick;
uint32_t tick[8];

void ticktimer(uint8_t n)
{
uint64_t current_tick;
uint32_t diff;
    current_tick = get_time();
    tick[n] = (uint32_t)(current_tick - prev_tick);
    prev_tick = current_tick;
    return;
}
