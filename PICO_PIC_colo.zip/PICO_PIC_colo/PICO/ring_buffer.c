
#include "pico/stdlib.h"
#include "ring_buffer.h"

void init_ring_buff( struct RING_BUFF *s, char *p_buff, uint size )
{
    s->read_posi = 0;
    s->write_posi = 0;
    s->buff_pointer = p_buff;
    s->buff_size = size;
    s->flag = BUFF_EMPTY;
}

void put_ring_buff( struct RING_BUFF *s, char c )
{
    if( s->flag == BUFF_FULL )s->flag = BUFF_ERROR;
    if( s->flag == BUFF_ERROR )return;

    *(s->buff_pointer+s->write_posi) = c;
    s->write_posi++;
    if( s->write_posi >= s->buff_size) s->write_posi = 0;
    s->flag = BUFF_NOT_EMPTY;

    if( s->write_posi == s->read_posi ) s->flag = BUFF_FULL;
}

char get_ring_buff( struct RING_BUFF *s )
{
    char c;
    if( s->flag == BUFF_EMPTY )return 0x00;

    c = *(s->buff_pointer+s->read_posi);
    s->read_posi++;
    if( s->read_posi >= s->buff_size) s->read_posi = 0;

    if( s->write_posi == s->read_posi ) s->flag = BUFF_EMPTY;
    return c;
}

void flush_ring_buff( struct RING_BUFF *s )
{
    while( s->flag != BUFF_EMPTY )
    {
        (void)get_ring_buff( s );
    }
}

