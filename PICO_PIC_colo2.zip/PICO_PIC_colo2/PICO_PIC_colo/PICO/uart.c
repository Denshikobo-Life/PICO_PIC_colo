/*
 * Copyright (c) 2021 Denshikobo-Life Ltd.
 *
 * License-Identifier: MIT
 */

#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/uart.h"
#include "hardware/irq.h"
#include "ring_buffer.h"

#define BAUD_RATE 115200
#define DATA_BITS 8
#define STOP_BITS 1
#define PARITY    UART_PARITY_NONE

enum PPC_rec_mode {
  REC_IDLE,
  REC_DEBUG,
  REC_USER,
  REC_REQUEST,
  REC_RESET
};

enum PPC_rec_mode PPC_uart_rec_mode;

bool PPC_command_send_request_flag;
extern bool user_send_request_flag;

bool PPC_command_rec_ready_flag;
extern bool user_rec_ready_flag;
bool PPC_receive_request_flag;
bool PPC_reset_request_flag;

#define BUFF_SIZE 2100
struct PPC_RING_BUFF PPC_uart_send_ring_buff;
char PPC_uart_send_buff[BUFF_SIZE];
struct PPC_RING_BUFF PPC_uart_receive_ring_buff;
char PPC_uart_receive_buff[BUFF_SIZE];

extern struct PPC_RING_BUFF PPC_command_receive_ring_buff;
extern struct PPC_RING_BUFF PPC_command_send_ring_buff;
extern struct PPC_RING_BUFF user_receive_ring_buff;
extern struct PPC_RING_BUFF user_send_ring_buff;

char PPC_debug_dump1[20];
char PPC_debug_dump2[20];
char PPC_debug_dump3[20];
uint PPC_debug_size;

char PPC_save_debug_dump1[20];
char PPC_save_debug_dump2[20];
char PPC_save_debug_dump3[20];
uint PPC_save_debug_size;

void PPC_push_dump( char *buff, char c )
{
    uint8_t posi;
    char s;

    for( posi=0;posi<20;posi++ )
    {
        s = buff[posi];
        buff[posi] = c;
        c = s;
    }
}


void PPC_save_dump( void)
{
    uint8_t posi;
    char c;
    for( posi=0;posi<20;posi++ )
    {
        c = PPC_debug_dump1[posi];
        PPC_save_debug_dump1[posi] = c;
        c = PPC_debug_dump2[posi];
        PPC_save_debug_dump2[posi] = c;
        c = PPC_debug_dump3[posi];
        PPC_save_debug_dump3[posi] = c;
    }
    PPC_save_debug_size = PPC_debug_size;
}

void PPC_break_point( uint8_t bp );

void PPC_setup_uart(void)
{
    PPC_init_ring_buff( &PPC_uart_receive_ring_buff, PPC_uart_receive_buff, BUFF_SIZE );
    PPC_init_ring_buff( &PPC_uart_send_ring_buff, PPC_uart_send_buff,BUFF_SIZE );

    PPC_uart_rec_mode = REC_IDLE;

    PPC_command_send_request_flag = false;
    user_send_request_flag = false;
    PPC_command_rec_ready_flag = false;
    user_rec_ready_flag = false;
    PPC_receive_request_flag = false;
    PPC_reset_request_flag = true;
}

bool PPC_first_time = true;

void PPC_receive_char( void )
{
int r;
    r = getchar();
    PPC_put_ring_buff( &PPC_uart_receive_ring_buff, (char)r );
}

void PPC_send_char( char c )
{
    putchar( c );
}

void PPC_message_send( char c1, char c2 )
{
    PPC_put_ring_buff( &PPC_uart_send_ring_buff, (char)0x03);
    PPC_put_ring_buff( &PPC_uart_send_ring_buff, c1);
    PPC_put_ring_buff( &PPC_uart_send_ring_buff, c2);
    PPC_put_ring_buff( &PPC_uart_send_ring_buff, (char)0x00);
}

void PPC_message_out( char c1, char c2 )
{
    PPC_send_char( (char)0x03 );
    PPC_send_char( c1 );
    PPC_send_char( c2 );
    PPC_send_char( (char)0x00 );
}

char PPC_convert_char( uint8_t h )
{
    if( h <= 9)return h+0x30;
    else return h - 10 + 'A';
}

void PPC_message_dump_hex( uint16_t d )
{
    uint8_t h;
    char c;
    PPC_send_char( (char)0x03 );

    h = (d>>12)&0x0f;
    c = PPC_convert_char( h );
    PPC_send_char( c );
    h = (d>>8)&0x0f;
    c = PPC_convert_char( h );
    PPC_send_char( c );
    h = (d>>4)&0x0f;
    c = PPC_convert_char( h );
    PPC_send_char( c );
    h = d&0x0f;
    c = PPC_convert_char( h );
    PPC_send_char( c );
    PPC_send_char( (char)0x00 );
}

void PPC_message_dump_buff( char *pointer )
{
    uint8_t loop;
    PPC_send_char( (char)0x03 );

    for( loop=0;loop<8;loop++)
      PPC_send_char( *pointer++ );
    PPC_send_char( (char)0x00 );
}

void PPC_uart_set_debugger_request(void) 
{
    char c;

    if( PPC_command_send_request_flag )
    {
        while( ( PPC_command_send_ring_buff.flag != BUFF_EMPTY )
            && ( PPC_uart_send_ring_buff.flag != BUFF_FULL) )
        {
            c = PPC_get_ring_buff( &PPC_command_send_ring_buff );
            PPC_put_ring_buff( &PPC_uart_send_ring_buff, c);
        }

        if(PPC_command_send_ring_buff.flag == BUFF_EMPTY)
        {
            PPC_command_send_request_flag = false;
        }
    }
}

void PPC_uart_set_user_request(void) 
{
    char c;
    if( user_send_request_flag )
    {
        while( ( user_send_ring_buff.flag != BUFF_EMPTY )
            && ( PPC_uart_send_ring_buff.flag != BUFF_FULL) )
        {
            c = PPC_get_ring_buff( &user_send_ring_buff );
            PPC_put_ring_buff( &PPC_uart_send_ring_buff, c);
        }

        if(user_send_ring_buff.flag == BUFF_EMPTY)
        {
            user_send_request_flag = false;
        }
    }
}

extern bool PPC_sec_flag;
void user_short_ope(void);
uint8_t PPC_send_loop_mode = 0;

// 0:idle 1:send user 2:send debugger

void PPC_uart_send_loop(void)
{
    char c;


    if( PPC_send_loop_mode == 0)
    {
        if( user_send_request_flag )
        {
            PPC_put_ring_buff( &PPC_uart_send_ring_buff, 0x02);
            PPC_send_loop_mode = 1;

        }
        else if( PPC_command_send_request_flag )
        {
            PPC_send_loop_mode = 2;
        }
    }

    if( PPC_send_loop_mode == 1 )
    {
        PPC_uart_set_user_request();
        if( !user_send_request_flag )
        {
            PPC_put_ring_buff( &PPC_uart_send_ring_buff, 0x00);
            PPC_send_loop_mode = 0;
        }
    }
    else if( PPC_send_loop_mode == 2 )
    {
        PPC_uart_set_debugger_request();
        if( !PPC_command_send_request_flag )
        {
            PPC_send_loop_mode = 0;
        }
    }

    while( PPC_uart_send_ring_buff.flag != BUFF_EMPTY )
    {
        c = PPC_get_ring_buff( &PPC_uart_send_ring_buff );
        PPC_send_char( c );
        user_short_ope();
    }
}

bool PPC_repeat_receive_flag = false;
extern bool PPC_receive_timing_flag;
void PPC_set_receive_time(void);
void PPC_ticktimer(uint8_t n);

uint8_t  PPC_reset_count;
void PPC_uart_receive_loop(void) 
{
    char c;

    if( ( !PPC_repeat_receive_flag )&&( !PPC_receive_timing_flag )) return;

    if( PPC_receive_timing_flag )
    {
        PPC_receive_timing_flag = false;
    }

    while( true )
    {
        c = getchar();
        switch( PPC_uart_rec_mode )
        {
        case REC_IDLE:
            if( c == 0x01 )
            {
                PPC_uart_rec_mode = REC_DEBUG;
                PPC_put_ring_buff( &PPC_command_receive_ring_buff, c);
            }
            else if( c == 0x02 )
            {
                PPC_uart_rec_mode = REC_USER;
            }
            else if( c == 0x03 )
            {
                PPC_uart_rec_mode = REC_REQUEST;
                PPC_repeat_receive_flag = true;
                PPC_save_dump();
            }
            else if( c == 0x04 )
            {
                PPC_uart_rec_mode = REC_RESET;
                PPC_repeat_receive_flag = true;
            }
            break;
        case REC_DEBUG:
            PPC_put_ring_buff( &PPC_command_receive_ring_buff, c);
            if( c == 0x00 )
            {
                PPC_command_rec_ready_flag = true;
                PPC_uart_rec_mode = REC_IDLE;
            }
            break;
        case REC_USER:
            if( c == 0x00 )
            {
                user_rec_ready_flag = true;
                PPC_uart_rec_mode = REC_IDLE;
            }
            else
            {
                PPC_put_ring_buff( &user_receive_ring_buff, c);
            }
            break;
        case REC_REQUEST:
            if( c == 0x00 )
            {
                PPC_receive_request_flag = true;
                PPC_uart_rec_mode = REC_IDLE;
            }
            break;
        case REC_RESET:
            if( c == 0x00 )
            {
                PPC_receive_request_flag = false;
                PPC_reset_request_flag = true;
                PPC_uart_rec_mode = REC_IDLE;
                PPC_repeat_receive_flag = false;
                PPC_set_receive_time();
            }
            break;
        default:
            break;
        }

        user_short_ope();

        if( PPC_reset_request_flag) 
        {
            PPC_reset_count++;
            if( PPC_reset_count >= 10 )
            {
                PPC_reset_count = 0;
            }
            break;
        }
    }
}
