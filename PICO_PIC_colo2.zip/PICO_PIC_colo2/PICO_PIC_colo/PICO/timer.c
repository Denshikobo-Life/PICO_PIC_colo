/*
 * Copyright (c) 2021 Denshikobo-Life Ltd.
 *
 * License-Identifier: MIT
 */


#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/timer.h"
#include "hardware/irq.h"

static uint64_t PPC_get_time(void) {
    // Reading low latches the high value
    uint32_t lo = timer_hw->timelr;
    uint32_t hi = timer_hw->timehr;
    return ((uint64_t) hi << 32u) | lo;
}

uint64_t PPC_current_time;
uint64_t PPC_ms_time;
uint64_t PPC_sub_sec_time;
uint64_t PPC_receive_time;
bool PPC_receive_timing_flag;
bool PPC_ms_flag;
bool PPC_sub_sec_flag;
uint16_t PPC_sub_sec_count;
bool PPC_sec_flag;
uint16_t PPC_ms_count;

extern bool user_ms_flag;
extern bool user_sub_sec_flag;

void PPC_start_ms_timer(void)
{
    PPC_current_time = PPC_get_time();
    PPC_ms_time = PPC_current_time + 1000;
    PPC_sub_sec_time = PPC_current_time + 100000;
    PPC_ms_flag = false;
    PPC_ms_count = 0;
    PPC_sub_sec_flag = false;
    PPC_sub_sec_count = 0;
    PPC_sec_flag = false;
    PPC_receive_time = PPC_sub_sec_time;
    PPC_receive_timing_flag = false;
}

void PPC_ms_timer(void)
{
    PPC_sec_flag = false;
    PPC_sub_sec_flag = false;
    PPC_ms_flag = false;
    PPC_current_time = PPC_get_time();
    if( PPC_ms_time <= PPC_current_time )
    {
        PPC_ms_flag = true;
        user_ms_flag = true;
        PPC_ms_time = PPC_current_time + 1000;
        PPC_ms_count++;
    }

    if( PPC_sub_sec_time <= PPC_current_time )
    {
        PPC_sub_sec_flag = true;
        user_sub_sec_flag = true;
        PPC_sub_sec_time +=  100000;
        PPC_sub_sec_count++;
        PPC_ms_count = 0;
        if( PPC_sub_sec_count >= 10 )
        {
            PPC_sec_flag = true;
            PPC_sub_sec_count = 0;
        }
    }

    if( PPC_receive_time <= PPC_current_time )
    {
        PPC_receive_timing_flag = true;
        PPC_receive_time +=  99000;
    }
}

void PPC_set_receive_time(void)
{
    PPC_receive_time = PPC_get_time() + 99000;
}

uint64_t PPC_prev_tick;
uint32_t PPC_tick[8];

void PPC_ticktimer(uint8_t n)
{
uint64_t current_tick;
uint32_t diff;
    current_tick = PPC_get_time();
    PPC_tick[n] = (uint32_t)(current_tick - PPC_prev_tick);
    PPC_prev_tick = current_tick;
    return;
}
