#include <stdio.h>
#include "pico/stdlib.h"

void PPC_reset_break_point(void);
void PPC_set_cp_auto( uint8_t cp);
void PPC_set_cp_hold( uint8_t cp);
void PPC_set_cp_pass( uint8_t cp);
void PPC_break_point( uint8_t bp );
void PPC_check_point(uint8_t cp);
void PPC_release_break(void);
void PPC_set_cp_sub_sec_clear( uint8_t cp);
void PPC_set_cp_sec_clear( uint8_t cp);
void PPC_set_cp_manual_clear( uint8_t cp);
