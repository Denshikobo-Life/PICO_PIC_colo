
#include "pico/stdlib.h"

enum PPC_ring_buff_flag {
  BUFF_EMPTY,
  BUFF_NOT_EMPTY,
  BUFF_FULL,
  BUFF_ERROR  
};

struct PPC_RING_BUFF
{
    uint16_t read_posi;
    uint16_t write_posi;
    char *buff_pointer;
    uint16_t buff_size;
    enum PPC_ring_buff_flag flag;
};

void PPC_init_ring_buff( struct PPC_RING_BUFF *s, char *p_buff, uint size );
void PPC_put_ring_buff( struct PPC_RING_BUFF *s, char c );
char PPC_get_ring_buff( struct PPC_RING_BUFF *s );
void PPC_flush_ring_buff( struct PPC_RING_BUFF *s );
