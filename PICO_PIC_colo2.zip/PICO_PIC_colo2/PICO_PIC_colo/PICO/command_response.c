/*
 * Copyright (c) 2021 Denshikobo-Life Ltd.
 *
 * License-Identifier: MIT
 */

#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/uart.h"
#include "hardware/irq.h"
#include "ring_buffer.h"

void PPC_set_command_send_request(void);

#define BUFF_SIZE 2100
struct PPC_RING_BUFF PPC_command_receive_ring_buff;  // external reference in uart.c
char PPC_command_receive_buff[BUFF_SIZE];
struct PPC_RING_BUFF PPC_command_send_ring_buff; // external reference in uart.c
char PPC_command_send_buff[BUFF_SIZE];

extern char PPC_debug_dump2[20];
extern char PPC_debug_dump3[20];
extern int PPC_debug_size;
void PPC_push_dump( char *buff, char c);

enum PPC_mode {
    COMM_IDLE,
    COMM_READ,
    COMM_WRITE,
    COMM_KILL,
    COMM_START,
    COMM_LOOPBACK,
    COMM_OTHER
};
enum PPC_mode PPC_comm_mode;

extern bool PPC_command_rec_ready_flag;
extern bool PPC_command_send_request_flag;
void PPC_release_break(void);

extern bool PPC_release;
bool PPC_send_bp_flag;

void PPC_command_response_init(void)
{
    PPC_init_ring_buff( &PPC_command_receive_ring_buff, PPC_command_receive_buff, BUFF_SIZE );
    PPC_init_ring_buff( &PPC_command_send_ring_buff, PPC_command_send_buff, BUFF_SIZE );
    PPC_comm_mode = COMM_IDLE;
}

uint8_t PPC_hex_char_to_int( char c )
{
    if( c < '0')return (uint8_t)0x0ff;
    else if( c <= '9')return (uint8_t)(c - 48);
    else if( ( 'A' <= c )&&( c<='F')) return (uint8_t)(c - 55);
    else if( ( 'a' <= c )&&( c<='f')) return (uint8_t)(c - 87);
    else return (uint8_t)0xff;
}

uint PPC_dec_char_to_int(  char c )
{
    if( c < '0')return -1;
    else if( c <= '9')return c - 48;
    else return -1;
}

// 'hhhhhhhh'
char PPC_address_string[8];

uint PPC_convert_address ( struct PPC_RING_BUFF *ring_buff )
{
    uint address;
    uint loop;
    char c;

    address = 0;
    for( loop = 0; loop<8; loop++)
    {
        address <<= 4;
        c = PPC_get_ring_buff( ring_buff );
        PPC_address_string[loop] = c;
        address += (uint)PPC_hex_char_to_int( c );
    }
    return address;
}


// 'ddd '
char PPC_size_string[5];

uint PPC_convert_size ( struct PPC_RING_BUFF *ring_buff )
{
    uint size;
    uint loop;
    char c;

    size = 0;
    PPC_size_string[0] = '0';
    PPC_size_string[1] = ' ';

    if( ring_buff->flag == BUFF_EMPTY )return size;

    for( loop = 0; loop<4; loop++)
    {
        c = PPC_get_ring_buff( ring_buff );

        if( c == (char)0x00 )
        {
            PPC_size_string[loop] = ' ';
            return size;
        }
        PPC_size_string[loop] = c;
        if( c == ' ') return size;
        size *= 10;
        size += PPC_dec_char_to_int( c );
        if( ring_buff->flag == BUFF_EMPTY )
        {
            PPC_size_string[loop+1] = ' ';
            return size;
        }
    }
    PPC_size_string[4] = ' ';
    return size;
}

uint8_t PPC_convert_byte ( struct PPC_RING_BUFF *ring_buff )
{
    uint8_t byte;
    char c;

    c = PPC_get_ring_buff( ring_buff );
    if( c == ' ')
    {
        c = PPC_get_ring_buff( ring_buff );
    }
    byte = PPC_hex_char_to_int( c );
    byte <<=4;
    c = PPC_get_ring_buff( ring_buff );
    byte += PPC_hex_char_to_int( c );
    return byte;
}

char PPC_hex_to_hexchar( uint8_t h )
{
    if( h <= 9 ) return (char)(h+48);
    else return (char)(h+87);
}

void PPC_put_ring_buff_byte ( struct PPC_RING_BUFF *ring_buff, uint8_t byte )
{
    char c;
    uint8_t h;

    h = (byte>>4);
    h &= 0x0f;
    c = PPC_hex_to_hexchar( h );
    PPC_put_ring_buff( ring_buff, c);

    h = (byte & 0x0f);
    c = PPC_hex_to_hexchar( h );
    PPC_put_ring_buff( ring_buff, c);
}

void PPC_put_ring_buff_hex4 ( struct PPC_RING_BUFF *ring_buff, uint16_t hex4 )
{
    uint8_t h;

    h = (uint8_t)( (hex4>>8) & 0x0ff );
    PPC_put_ring_buff_byte ( ring_buff, h );

    h = (uint8_t)( hex4 & 0x0ff );
    PPC_put_ring_buff_byte ( ring_buff, h );
}

uint8_t PPC_get_ring_buff_byte ( struct PPC_RING_BUFF *ring_buff )
{
    char c;
    uint8_t h;

    c = PPC_get_ring_buff( ring_buff );
    h = PPC_hex_char_to_int( c );
    PPC_push_dump( PPC_debug_dump2,c);

    h <<=4;

    c = PPC_get_ring_buff( ring_buff );
    h += PPC_hex_char_to_int( c );
    PPC_push_dump( PPC_debug_dump2,c);

    return h;
}

void PPC_uart_set_debugger_request(void);

extern int PPC_pattern;
extern int pattern;
extern bool PPC_kill_flag;
extern bool PPC_start_flag;
void message_out( char c1, char c2 );
extern bool PPC_reset_request_flag;

extern uint16_t PPC_pass_count[16];
extern uint8_t PPC_hold_mode[16];        // 0:pass 1:hold 2:auto reset
extern uint8_t PPC_break_point_num;
extern bool PPC_sec_flag;
extern uint16_t PPC_hold_pass_count[16];

void PPC_clear_hold_pass_count(void);
void PPC_release_break(void);
void PPC_clear_manual_pass_count(void);

bool PPC_send_b_p = false;
bool PPC_send_p_c = false;
bool PPC_send_h_m = false;

void PPC_command_response_main(void)
{
    uint8_t *pointer;
    char c;
    uint address;
    uint size;
    uint loop;
    uint8_t byte;
    uint16_t hex4;

    while( PPC_command_rec_ready_flag )
    {
        switch( PPC_comm_mode )
        {
        case COMM_IDLE:
            c = PPC_get_ring_buff( &PPC_command_receive_ring_buff );
            // c = 0x01
            c = PPC_get_ring_buff( &PPC_command_receive_ring_buff );
            // c = 'W' or 'R' or else?
            if(c == 'R') PPC_comm_mode = COMM_READ;
            else if(c == 'W') PPC_comm_mode = COMM_WRITE;
            else if(c=='L') PPC_comm_mode = COMM_LOOPBACK;
            else if(c=='K') PPC_comm_mode = COMM_KILL;
            else if(c=='S') PPC_comm_mode = COMM_START;
            else if(c=='O') PPC_comm_mode = COMM_OTHER;
            else PPC_comm_mode = COMM_OTHER;
            break;
        case COMM_READ:
            // hhhhhhhh
            c = PPC_get_ring_buff( &PPC_command_receive_ring_buff ); // ' '
            address = PPC_convert_address( &PPC_command_receive_ring_buff );
            c = PPC_get_ring_buff( &PPC_command_receive_ring_buff ); // ' '
            size = PPC_convert_size( &PPC_command_receive_ring_buff);

            // create response
            PPC_put_ring_buff( &PPC_command_send_ring_buff,(char)0x01 );
            PPC_put_ring_buff( &PPC_command_send_ring_buff,'r' );
            PPC_put_ring_buff( &PPC_command_send_ring_buff,' ' );

            // 'hhhhhhhh'
            for(loop=0;loop<8;loop++)
            {
                c = PPC_address_string[loop];
                PPC_put_ring_buff( &PPC_command_send_ring_buff, c );
            }

            PPC_put_ring_buff( &PPC_command_send_ring_buff, ' ' );
            for(loop=0;loop<4;loop++)
            {
                c = PPC_size_string[loop];
                PPC_put_ring_buff( &PPC_command_send_ring_buff, c );
                if(c== ' ')break;
            }
            if(c!= ' ') PPC_put_ring_buff( &PPC_command_send_ring_buff, ' ' );

            pointer = (uint8_t *)address;
            if( size > 1024 )size = 1024;   // send 2048bytes
            for( loop=0;loop<size;loop++ )
            {
                byte = *pointer;
                pointer++;
                PPC_put_ring_buff_byte( &PPC_command_send_ring_buff, byte );
            }
            PPC_put_ring_buff( &PPC_command_send_ring_buff, (char)0x00 );
            PPC_flush_ring_buff( &PPC_command_receive_ring_buff );
            PPC_command_rec_ready_flag = false;
            PPC_command_send_request_flag = true;
            PPC_comm_mode = COMM_IDLE;
            break;
        case COMM_WRITE:
            //W hhhhhhhh d. hhhhhhh..
            // skip space
            c = PPC_get_ring_buff( &PPC_command_receive_ring_buff ); // ' '
            // get address
            address = PPC_convert_address( &PPC_command_receive_ring_buff );
            // skip space
            c = PPC_get_ring_buff( &PPC_command_receive_ring_buff ); // ' '
            // get size
            size = PPC_convert_size( &PPC_command_receive_ring_buff);
            PPC_debug_size = size;

            // create response
            PPC_put_ring_buff( &PPC_command_send_ring_buff,(char)0x01 );
            PPC_put_ring_buff( &PPC_command_send_ring_buff,'w' );
            PPC_put_ring_buff( &PPC_command_send_ring_buff,' ' );

            // 'hhhhhhhh'
            for(loop=0;loop<8;loop++)
            {
                c = PPC_address_string[loop];
                PPC_put_ring_buff( &PPC_command_send_ring_buff, c );
            }

            PPC_put_ring_buff( &PPC_command_send_ring_buff, ' ' );
            for(loop=0;loop<4;loop++)
            {
                c = PPC_size_string[loop];
                PPC_put_ring_buff( &PPC_command_send_ring_buff, c );
                if(c== ' ')break;
            }
            if(c!= ' ')
            {
                PPC_put_ring_buff( &PPC_command_send_ring_buff, ' ' );
                // skip space
                c = PPC_get_ring_buff( &PPC_command_receive_ring_buff ); // ' '
            }

            pointer = (uint8_t *)address;
            if( size > 1024 )size = 1024;
            for( loop=0;loop<size;loop++ )
            {
                byte = PPC_get_ring_buff_byte ( &PPC_command_receive_ring_buff );
                *pointer = byte;
                pointer++;
            }
            PPC_put_ring_buff( &PPC_command_send_ring_buff, (char)0x00 );
            PPC_flush_ring_buff( &PPC_command_receive_ring_buff );
            PPC_command_rec_ready_flag = false;
            PPC_command_send_request_flag = true;
            PPC_comm_mode = COMM_IDLE;
            break;
        case COMM_KILL:
            // create response common
            PPC_kill_flag = true;
            PPC_put_ring_buff( &PPC_command_send_ring_buff,(char)0x01 );
            PPC_put_ring_buff( &PPC_command_send_ring_buff,'k' );
            PPC_put_ring_buff( &PPC_command_send_ring_buff,' ' );
            PPC_put_ring_buff( &PPC_command_send_ring_buff, (char)0x00 );
            PPC_flush_ring_buff( &PPC_command_receive_ring_buff );
            // common response
            PPC_command_rec_ready_flag = false;
            PPC_command_send_request_flag = true;
            PPC_comm_mode = COMM_IDLE;
            break;
        case COMM_START:
            // create response common
            PPC_start_flag = true;
            PPC_put_ring_buff( &PPC_command_send_ring_buff,(char)0x01 );
            PPC_put_ring_buff( &PPC_command_send_ring_buff,'s' );
            PPC_put_ring_buff( &PPC_command_send_ring_buff,' ' );
            PPC_put_ring_buff( &PPC_command_send_ring_buff, (char)0x00 );
            PPC_flush_ring_buff( &PPC_command_receive_ring_buff );
            // common response
            PPC_command_rec_ready_flag = false;
            PPC_command_send_request_flag = true;
            PPC_comm_mode = COMM_IDLE;
            break;
        case COMM_LOOPBACK:
            PPC_put_ring_buff( &PPC_command_send_ring_buff,'l' );
            while( PPC_command_receive_ring_buff.flag != BUFF_EMPTY )
            {
                c = PPC_get_ring_buff( &PPC_command_receive_ring_buff );
                PPC_put_ring_buff( &PPC_command_send_ring_buff, c );
            }
            PPC_command_send_request_flag = true;
            PPC_command_rec_ready_flag = false;
            PPC_comm_mode = COMM_IDLE;
            break;
        case COMM_OTHER:
                PPC_put_ring_buff( &PPC_command_send_ring_buff,(char)0x01 );
                PPC_put_ring_buff( &PPC_command_send_ring_buff,'o' );
                PPC_put_ring_buff( &PPC_command_send_ring_buff,' ' );
            // skip space
            c = PPC_get_ring_buff( &PPC_command_receive_ring_buff ); // ' '
            // get 2nd LETTER
            c = PPC_get_ring_buff( &PPC_command_receive_ring_buff ); // 'R'
            if( c=='R' )
            {
            // Break Release
                PPC_release_break();
                PPC_release = true;
                PPC_put_ring_buff( &PPC_command_send_ring_buff,'r' );
                PPC_put_ring_buff( &PPC_command_send_ring_buff,' ' );
            }
            else if( c=='C')
            {
            // manual_clear
                PPC_clear_manual_pass_count();
                PPC_put_ring_buff( &PPC_command_send_ring_buff,'c' );
                PPC_put_ring_buff( &PPC_command_send_ring_buff,' ' );
            }
            PPC_flush_ring_buff( &PPC_command_receive_ring_buff );
            // common response
            PPC_put_ring_buff( &PPC_command_send_ring_buff, (char)0x00 );
            PPC_command_rec_ready_flag = false;
            PPC_command_send_request_flag = true;
            PPC_comm_mode = COMM_IDLE;
            break;
        }
    }

    if( PPC_sec_flag )
    {
        PPC_send_b_p = true;
        PPC_send_h_m = true;
        PPC_send_p_c = true;
    }

// exec. per 0.1sec
    if( PPC_reset_request_flag )
    {
        PPC_reset_request_flag = false;

        if( PPC_send_b_p )
        {
            PPC_send_b_p = false;
            PPC_put_ring_buff( &PPC_command_send_ring_buff,(char)0x01 );
            PPC_put_ring_buff( &PPC_command_send_ring_buff, 'B' );
            PPC_put_ring_buff( &PPC_command_send_ring_buff, ' ' );
            PPC_put_ring_buff_byte( &PPC_command_send_ring_buff, PPC_break_point_num );
            PPC_put_ring_buff( &PPC_command_send_ring_buff,(char)0x00 );
            PPC_send_bp_flag = true;
        }
        else if( PPC_send_p_c )
        {
            PPC_send_p_c = false;
            PPC_put_ring_buff( &PPC_command_send_ring_buff,(char)0x01 );
            PPC_put_ring_buff( &PPC_command_send_ring_buff, 'P' );
            PPC_put_ring_buff( &PPC_command_send_ring_buff, ' ' );
            pointer = (uint8_t *)PPC_hold_pass_count;
            for( loop=0;loop<32;loop++ )
            {
                PPC_put_ring_buff_byte ( &PPC_command_send_ring_buff, *pointer );
                pointer++;
            }
            PPC_put_ring_buff( &PPC_command_send_ring_buff,(char)0x00 );
//            clear_hold_pass_count();
        }
        else if( PPC_send_h_m )
        {
            PPC_send_h_m = false;
            PPC_put_ring_buff( &PPC_command_send_ring_buff,(char)0x01 );
            PPC_put_ring_buff( &PPC_command_send_ring_buff, 'H' );
            PPC_put_ring_buff( &PPC_command_send_ring_buff, ' ' );
            pointer = (uint8_t *)PPC_hold_mode;
            for( loop=0;loop<16;loop++ )
            {
                PPC_put_ring_buff_byte( &PPC_command_send_ring_buff, *pointer );
                pointer++;
            }
            PPC_put_ring_buff( &PPC_command_send_ring_buff,(char)0x00 );
        }

        PPC_put_ring_buff( &PPC_command_send_ring_buff,(char)0x01 );
        PPC_put_ring_buff( &PPC_command_send_ring_buff,'b' );
        PPC_put_ring_buff( &PPC_command_send_ring_buff,(char)0x00 );
        PPC_command_send_request_flag = true;
    }
}
