#include <stdio.h>
#include <string.h>
#include "pico/stdlib.h"
#include "pico/binary_info.h"
#include "hardware/i2c.h"
#include "ring_buffer.h"
#include "check_point.h"
#include "pico/time.h"
#include "pico/multicore.h"


void PPC_put_ring_buff_byte ( struct PPC_RING_BUFF *ring_buff, uint8_t byte );
void PPC_uart_set_user_request(void); 
void core1_entry(void);

bool user_rec_ready_flag;      
bool user_send_request_flag;   

uint8_t version;

#define BUFF_SIZE 2100
struct PPC_RING_BUFF user_receive_ring_buff;   
char user_receive_buff[BUFF_SIZE];
struct PPC_RING_BUFF user_send_ring_buff;  
char user_send_buff[BUFF_SIZE];

bool user_sub_sec_flag;   
bool user_ms_flag;       
uint8_t meas_5ms_count;


// call from main_init() @PICO_Pic_colo.c
void user_init(void)
{
    version = 0x01;
    PPC_init_ring_buff( &user_receive_ring_buff, user_receive_buff, BUFF_SIZE );
    PPC_init_ring_buff( &user_send_ring_buff, user_send_buff,BUFF_SIZE );

    PPC_set_cp_pass(0);  // Set Pass mode
    PPC_set_cp_pass(1);  // 
    PPC_set_cp_pass(2);
    PPC_set_cp_pass(3);
    PPC_set_cp_pass(4);
    PPC_set_cp_pass(5);  // 

    PPC_set_cp_sub_sec_clear(0);  // Set sub_sec_clear mode
    PPC_set_cp_manual_clear(1);  // Set manual_clear_mode
    PPC_set_cp_manual_clear(2);
    PPC_set_cp_manual_clear(3);
    PPC_set_cp_manual_clear(4);
    PPC_set_cp_manual_clear(5);  // large_buff
    multicore_reset_core1 ();
    multicore_launch_core1(core1_entry);

    meas_5ms_count = 0;
}


// call from uart send/receive loop
// short means less than 50us
void user_short_ope(void)
{
    if( user_ms_flag )
    {
        user_ms_flag = false;
    }
    return;
}

// call from main_loop() @PICO_Pic_colo.c
// so, call is stop when uart send/receive looping
void user_main() {
    char c;
    int ret;
    uint8_t loop;
    uint8_t rxdata;
    uint8_t addr;
    uint8_t i;

    PPC_check_point(0);
    user_short_ope();

    if( user_sub_sec_flag )
    {
        user_sub_sec_flag = false;
    }

    if( user_rec_ready_flag )
    {
        user_rec_ready_flag = false;
        PPC_check_point(1);
        while( user_receive_ring_buff.flag == BUFF_NOT_EMPTY )
        {
            c = PPC_get_ring_buff( &user_receive_ring_buff );
            PPC_put_ring_buff( &user_send_ring_buff, c);
        }

        user_send_request_flag = true;
        PPC_check_point(2);
        PPC_check_point(3);
        PPC_check_point(4);
        PPC_check_point(5);
    }
}

int pattern;
const uint LED_PIN = 25;

void blink_n( int n )
{
    int loop;
    for (loop=0;loop<n;loop++ )
    {
        gpio_put(LED_PIN, 1);
        sleep_ms(50);
        gpio_put(LED_PIN, 0);
        sleep_ms(50);
    }
    sleep_ms(100);
}

void core1_entry() 
{
    gpio_init(LED_PIN);
    gpio_set_dir(LED_PIN, GPIO_OUT);
    pattern = 10;
    while (true) {
        if( pattern == 0 )
        {
            sleep_ms(1);
        }
        else if( pattern == 10 )
        {
            gpio_put(LED_PIN, 1);
            sleep_ms(250);
            gpio_put(LED_PIN, 0);
            sleep_ms(250);
        }
        else
        {
            blink_n( pattern );
            pattern = 0;
        }
    }
}
