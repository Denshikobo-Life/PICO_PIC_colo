/*
 * Copyright (c) 2021 Denshikobo-Life Ltd.
 *
 * License-Identifier: MIT
 */

#include <stdio.h>
#include "pico/stdlib.h"
#include "check_point.h"

uint16_t PPC_pass_count[16];
uint8_t PPC_hold_mode[16];        // 0:pass 1:hold 2:auto reset
uint8_t PPC_clear_count_mode[16]; // 0:clear per sec 1:clear per sub_sec 2:manual clear
uint8_t PPC_break_point_num;
bool PPC_release;
uint16_t PPC_hold_pass_count[16];
bool PPC_manual_clear;

#define PASS_MODE 0
#define HOLD_MODE 1
#define AUTO_MODE 2

#define SUB_SEC_CLEAR_MODE 0
#define SEC_CLEAR_MODE 1
#define MANUAL_CLEAR_MODE 2

uint16_t PPC_auto_loop_count;
uint16_t PPC_auto_release_count;
uint16_t PPC_pass_clear_count;
uint16_t PPC_break_point_timer;
uint16_t PPC_break_loop_count;
uint16_t PPC_break_sub_sec_count;
bool PPC_hold_flag;

extern bool PPC_sec_flag;
extern bool PPC_sub_sec_flag;
extern bool PPC_send_bp_flag;
extern uint16_t PPC_sub_sec_count;

void PPC_clear_pass_count(void)
{
    uint8_t loop;
    for (loop = 0; loop < 16; loop++)
    {
        if ((PPC_sub_sec_flag) && (PPC_clear_count_mode[loop] == SUB_SEC_CLEAR_MODE))
        {
            PPC_hold_pass_count[loop] = PPC_pass_count[loop];
            PPC_pass_count[loop] = 0;
        }
        else if ((PPC_sec_flag) && (PPC_clear_count_mode[loop] == SEC_CLEAR_MODE))
        {
            PPC_hold_pass_count[loop] = PPC_pass_count[loop];
            PPC_pass_count[loop] = 0;
        }
        else if ((PPC_manual_clear) && (PPC_clear_count_mode[loop] == MANUAL_CLEAR_MODE))
        {
            PPC_hold_pass_count[loop] = 0;
            PPC_pass_count[loop] = 0;
        }
    }
    PPC_manual_clear = false;
}

void PPC_clear_hold_pass_count(void)
{
    uint8_t loop;
    for (loop = 0; loop < 16; loop++)
    {
        PPC_hold_pass_count[loop] = 0;
    }
}

void PPC_reset_check_point(void)
{
    uint8_t loop;

    for (loop = 0; loop < 16; loop++)
    {
        PPC_pass_count[loop] = 0;
        PPC_hold_mode[loop] = PASS_MODE;
        PPC_clear_count_mode[loop] = SUB_SEC_CLEAR_MODE;
    }
    PPC_break_point_num = 16;
    PPC_release = false;
    PPC_pass_clear_count = 10;
}

void PPC_command_response_main(void);
void PPC_ms_timer(void);
void PPC_uart_send_loop(void);
void PPC_uart_receive_loop(void);

extern uint16_t PPC_sub_ms_count;

void PPC_set_cp_auto(uint8_t cp)
{
    PPC_hold_mode[cp] = AUTO_MODE;
}

void PPC_set_cp_hold(uint8_t cp)
{
    PPC_hold_mode[cp] = HOLD_MODE;
}

void PPC_set_cp_pass(uint8_t cp)
{
    PPC_hold_mode[cp] = PASS_MODE;
}

void PPC_set_cp_sub_sec_clear(uint8_t cp)
{
    PPC_clear_count_mode[cp] = SUB_SEC_CLEAR_MODE;
}

void PPC_set_cp_sec_clear(uint8_t cp)
{
    PPC_clear_count_mode[cp] = SEC_CLEAR_MODE;
}

void PPC_set_cp_manual_clear(uint8_t cp)
{
    PPC_clear_count_mode[cp] = MANUAL_CLEAR_MODE;
}


extern char PPC_debug_dump1[20];

void PPC_push_dump( char *buff, char c );

void PPC_break_point(uint8_t bp)
{
    PPC_pass_count[bp]++;
    if (PPC_pass_count[bp] >= 60000)
    {
        PPC_pass_count[bp] = 60000;
    }

    if (PPC_clear_count_mode[bp] == MANUAL_CLEAR_MODE)
    {
        PPC_hold_pass_count[bp] = PPC_pass_count[bp];
    }

    if (PPC_sub_sec_flag)
    {
        PPC_clear_pass_count();
    }

    if (PPC_hold_mode[bp] == PASS_MODE)
        return;
    PPC_hold_flag = true;
    PPC_break_point_num = bp;
    if (PPC_hold_mode[bp] == AUTO_MODE)
    {
        PPC_auto_loop_count = 0;
        PPC_hold_flag = true;
        while ((PPC_auto_loop_count < PPC_auto_release_count) || (!PPC_send_bp_flag))
        {
            PPC_ms_timer();
            if (PPC_sub_sec_flag)
                PPC_auto_loop_count++;
            PPC_uart_send_loop();
            PPC_uart_receive_loop();
            PPC_command_response_main();
            if (!PPC_hold_flag)
                break;
        }
        PPC_send_bp_flag = false;
    }
    else if (PPC_hold_mode[bp] == HOLD_MODE)
    {
        while ((PPC_hold_flag) && (PPC_hold_mode[bp] == HOLD_MODE))
        {
            PPC_ms_timer();
            PPC_uart_send_loop();
            PPC_uart_receive_loop();
            PPC_command_response_main();
        }
    }
    PPC_break_point_num = 16;
}

void PPC_check_point(uint8_t cp)
{
    PPC_break_point(cp);
}

void PPC_release_break(void)
{
    PPC_hold_flag = false;
}

void PPC_clear_manual_pass_count(void)
{
    PPC_manual_clear = true;
}
