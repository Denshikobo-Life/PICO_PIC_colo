/*
 * Copyright (c) 2021 Denshikobo-Life Ltd.
 *
 * License-Identifier: MIT
 */

#include <stdio.h>
#include "pico/stdlib.h"
#include "pico/binary_info.h"

void user_init();
void user_main();
void PPC_setup_uart(void);
void PPC_uart_main(void);
void PPC_command_response_init(void);
void PPC_command_response_main(void);
void PPC_reset_break_point(void);
void PPC_start_ms_timer(void);
void PPC_ms_timer(void);

void PPC_clear_pass_count(void);
void PPC_reset_check_point(void);

bool PPC_kill_flag;
bool PPC_start_flag;
uint8_t PPC_sec_count;
extern uint16_t PPC_auto_release_count;
extern uint16_t PPC_pass_clear_count;

void PPC_main_init()
{
    stdio_init_all();

    PPC_setup_uart();
    PPC_command_response_init();
    PPC_reset_check_point();
    PPC_auto_release_count = 30;
    PPC_pass_clear_count = 10;

    user_init();

    PPC_start_ms_timer();
    PPC_sec_count = 0;
    PPC_kill_flag = false;
    PPC_start_flag =  false;
}

extern volatile bool PPC_sec_flag;
void PPC_uart_send_loop(void);
void PPC_uart_receive_loop(void);

uint16_t PPC_main_loop_count;
uint16_t PPC_main_loop_hold_count;

void PPC_ticktimer(uint8_t n);
void PPC_main_loop()
{
    PPC_ms_timer();
    if( PPC_sec_flag )
    {
        PPC_main_loop_hold_count = PPC_main_loop_count;
        PPC_main_loop_count = 0;
    }

    PPC_uart_receive_loop();
    PPC_command_response_main();
    user_main();
    PPC_uart_send_loop();

    PPC_main_loop_count++;
}


void PPC_reset_break_point(void);

int main() {
int r;
    PPC_main_init();

    while (true) {
        PPC_main_loop();
        if( PPC_kill_flag )
        {
            sleep_ms(3000);
            *((int *)0xE000ED0C) = 0x05FA0004;
        }
        if( PPC_start_flag )
        {
            PPC_start_flag = false;
            sleep_ms(3000);
            PPC_main_init();
        }
    }
    return 0;
}
