#!/usr/bin/env python
#-*-:utf-8

import sys
import time
import PySimpleGUI as sg
import PICO_PIC_colo_comm as comm
import PICO_PIC_colo_analyze as analyze
import PICO_PIC_colo_pickle as pickle_dict
import custom_window as custom
import PICO_PIC_colo_timer

show_data_flag = False
show_data_window = sg.Window('')
show_data_mode = ''
show_data_list = []

current_time = 0
prev_time = 0
LED_reset_time = 0
update_flag = False

def LEDIndicator(key=None, radius=30):
    return sg.Graph(canvas_size=(radius, radius),
             graph_bottom_left=(-radius, -radius),
             graph_top_right=(radius, radius),
             pad=(0, 0), key=key)

def SetLED(window, key, color):
    graph = window[key]
    graph.erase()
    graph.draw_circle((0, 0), 12, fill_color=color, line_color=color)
    return

def create_window( window_parameter ):
    global show_data_window
    global show_data_list

    x = window_parameter[0]
    y = window_parameter[1]

    param = window_parameter[2]

    show_data_mode = 'HOLD'
    show_data_list = pickle_dict.get_dict( 'disp_var_list')
    if show_data_list == None: show_data_list = []
    show_data_layout = [
            [sg.Text('Show DATA')],
            [ sg.Text(show_data_mode, key='-Show Mode-'), sg.Button('Change') ],
            [ sg.Listbox(show_data_list, size=(40, 10) , key='-Disp LIST-' ) ],
            [ sg.Button('Update'), LEDIndicator('_update LED_'),sg.Text(' ',size=(19,1)),sg.Button('Send')],
            [ sg.InputText('Write Command',size=(40,1),key='-Write-')]
        ]
    show_data_window = sg.Window('Show DATA', show_data_layout,location=(x,y),**param)
    show_data_flag = True
    return

def update_disp_list():
    global current_disp_data_list
    show_data_list = pickle_dict.get_dict( 'disp_var_list')
    show_data_window['-Disp LIST-'].update( show_data_list )
    show_data_window['-Write-'].update( '')
    current_disp_data_list = show_data_list

def show_window():
    global show_data_flag
    global current_time 
    global prev_time
    global LED_reset_time
    global show_data_list

    show_data_list = pickle_dict.get_dict( 'disp_var_list')
    show_data_window['-Disp LIST-'].update( show_data_list )

    show_data_window.UnHide()
    show_data_flag = True
    SetLED(show_data_window, '_update LED_', 'white' )
    current_time = time.time()
    prev_time = current_time
    LED_reset_time = current_time
    return

def get_var_data( v_list ):
    if comm.check_send_buffer_clear() == False:
        return ['Comm ','Error','debbuger send buffer is NOT empty ']

    if comm.check_receive_buffer_clear() == False:
        return ['Comm ','Error','debbuger receive buffer is NOT empty ']

    read_list = []
    for var_data in v_list:
        comm_str = 'R '+var_data[1]+' '+var_data[2]
        comm.debugger_send( comm_str )
        comm.wait_until_receive_response()
        receive_str = comm.debugger_receive()
        receive_list = receive_str.split(' ')
        if  len(receive_list)>= 4 :
            read_list.append( [ var_data[0],receive_list[1], receive_list[2], receive_list[3]] )
    return read_list

current_disp_data_list = []

def window_operation():
    global show_data_flag
    global show_data_mode
    global prev_time
    global update_flag
    global current_disp_data_list

    if show_data_flag:
        current_time = time.time()

        if update_flag:
            show_data_list = pickle_dict.get_dict( 'disp_var_list')
            if( len(show_data_list) != 0):
                disp_data_list = get_var_data(show_data_list)
                show_data_window['-Disp LIST-'].update( disp_data_list )
                current_disp_data_list = disp_data_list
            update_flag = False
            prev_time = current_time
            SetLED(show_data_window, '_update LED_', 'white' )

        if show_data_mode == 'AUTO' :
            if current_time > prev_time + 2.0 :
                update_flag = True
                SetLED(show_data_window, '_update LED_', 'green' )

        event, values = show_data_window.read(timeout = 0)
        if event == 'Change':
            if show_data_mode == 'HOLD':
                show_data_mode = 'AUTO'
            else :
                show_data_mode = 'HOLD'
            show_data_window['-Show Mode-'].update(show_data_mode)
        elif event == 'Update':
            update_flag = True
            SetLED(show_data_window, '_update LED_', 'green' )
        elif event == 'Send':
            write_str = show_data_window['-Write-'].get()
            element = write_str.split(' ')
            if len(element)>=4 :
                comm_str = 'W '+element[1]+' '+element[2]+' '+element[3]+' '
                comm.debugger_send( comm_str )
                comm.wait_until_receive_response()
                receive_str = comm.debugger_receive()
        elif event == 'Quit':
            show_data_window.Hide()
            show_data_flag = False

        if PICO_PIC_colo_timer.ten_ms_flag :
            select_data = show_data_window['-Disp LIST-'].get()
            if select_data != [] :
                write_str = ''
                for element in select_data[0]:
                    write_str += element
                    write_str += ' '
                show_data_window['-Write-'].update( write_str )
                show_data_window['-Disp LIST-'].update( current_disp_data_list )

def open_close():
    global show_data_flag
    if show_data_flag:
        show_data_window.Hide()
        show_data_flag = False
    else:
        show_window()

def close():
    global show_data_flag
    if show_data_flag:
        show_data_window.Hide()
        show_data_flag = False
