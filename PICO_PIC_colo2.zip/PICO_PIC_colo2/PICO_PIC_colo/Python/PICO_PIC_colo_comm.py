#!/usr/bin/env python
#-*-:utf-8

from pickle import TRUE
import serial
import PySimpleGUI as sg
import time
import PICO_PIC_colo_timer as PICO_timer

uartport = None

def open():
    global uartport
    uartport = serial.Serial(
                port="/dev/ttyACM0",
#                port="COM5",
#                port="/dev/ttyS0",
                baudrate=115200,
                bytesize=serial.EIGHTBITS,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                timeout=0)
    uartport.reset_input_buffer()
    uartport.reset_output_buffer()

def close():
    uartport.close()

def send_serial( send_str ):
    uartport.write(( send_str ).encode("utf-8") )

user_send_buffer= []
user_receive_buffer= []
debugger_send_buffer= []
debugger_receive_buffer= []
r_data = b''

send_count = 0
wait_response_flag = False
repeat_receive_flag = False

debug_flag = False

def send_main():
    global send_count
    global wait_response_flag
    global repeat_receive_flag
    global debug_flag

    if len(debugger_send_buffer ) != 0 and PICO_timer.send_timing_flag :
        PICO_timer.send_timing_flag = False
        send_txt = '\x03'+'\x00'
        send_serial( send_txt )
        while len(debugger_send_buffer ) != 0:
            buff_str = debugger_send_buffer.pop(0)
            if len(buff_str)>=2098 :
                send_txt = '\x01'+buff_str[:2098]+'\x00'
            else :
                send_txt = '\x01'+buff_str+'\x00'
            send_serial( send_txt )
        send_txt = '\x04'+'\x00'
        send_serial( send_txt )
        wait_response_flag = True
        repeat_receive_flag = True
        PICO_timer.set_send_time( 0.5 )     # error recovery see line 105

    if len(user_send_buffer ) != 0 and PICO_timer.send_timing_flag :
        PICO_timer.send_timing_flag = False
        send_txt = '\x03'+'\x00'
        send_serial( send_txt )
        while len(user_send_buffer ) != 0:
            buff_str = user_send_buffer.pop(0)
#            print('USER SEND'+buff_str )
            debug_flag = True
            if len(buff_str)>=2098 :
                send_txt = '\x02'+buff_str[:2098]+'\x00'
            else :
                send_txt = '\x02'+buff_str+'\x00'
            send_serial( send_txt )
        send_txt = '\x04'+'\x00'
        send_serial( send_txt )
        wait_response_flag = True
        repeat_receive_flag = True
        PICO_timer.set_send_time( 0.5 ) # error recovery

    if PICO_timer.send_timing_flag :
        PICO_timer.send_timing_flag = False
        send_txt = '\x04'+'\x00'
        send_serial( send_txt )
        wait_response_flag = True
        repeat_receive_flag = True
        PICO_timer.set_send_time( 0.5 ) # error recovery

receive_b_flag = False
break_point_data = ''
pass_count_data = ''
hold_mode_data = ''

def receive_main():
    global r_data
    global receive_b_flag
    global repeat_receive_flag
    global break_point_data
    global pass_count_data
    global hold_mode_data

    PICO_timer.sub_sec_loop_count = 0
    while repeat_receive_flag :
        r_c = uartport.read()
        if r_c != b'' :
            r_data += r_c
        if r_c == b'\x00' :
            if len(r_data) >= 2:
                if r_data[0] == 1 and r_data[-1] == 0:
                    rec_str = r_data.decode("utf-8")[1:-1]
                    if rec_str[0] == 'b' :
                        receive_b_flag = True
                        PICO_timer.set_send_time( 0.05 )
                        repeat_receive_flag = False
                    elif rec_str[0] == 'B' :
                        break_point_data = r_data.decode("utf-8")[1:-1]
                    elif rec_str[0] == 'P' :
                        pass_count_data = r_data.decode("utf-8")[1:-1]
                    elif rec_str[0] == 'H' :
                        hold_mode_data = r_data.decode("utf-8")[1:-1]
                    else :
                        debugger_receive_buffer.append( rec_str )
                elif r_data[0] == 2 and r_data[-1] == 0:
                    user_receive_buffer.append( r_data.decode("utf-8")[1:-1])
                elif r_data[0] == 3 and r_data[-1] == 0:
                    print( r_data.decode("utf-8")[1:-1] )
            r_data = b''
        PICO_timer.main()
        if PICO_timer.sub_sec_loop_count > 50 :
            print( 'Receive time out')
            break

def main():
    send_main();
    receive_main();

def user_send(s_text):
    user_send_buffer.append( s_text )
#    print( 'user send '+s_text)
#    wait_until_send_timing()
#    send_main()

def user_receive():
    if len( user_receive_buffer ) != 0:
        return user_receive_buffer.pop(0)
    else : return ''

def wait_until_user_response():
    global receive_b_flag
    PICO_timer.sub_sec_loop_count = 0
    while len( user_receive_buffer ) == 0:
        PICO_timer.main()
        send_main()
        receive_main()
        if PICO_timer.sub_sec_loop_count > 50 :
            print('wait_loop error')
            break
    return




    #     PICO_timer.main()
    #     send_main()
    #     receive_main()
    #     if PICO_timer.sub_sec_flag :
    #         loop_count+=1
    #         if loop_count > 5:
    #             print('response time_out')
    #             return False
    # return True

def check_send_buffer_clear():
    if len( debugger_send_buffer ) != 0:
        return False
    return True

def check_receive_buffer_clear():
    while len( debugger_receive_buffer ) != 0:
        rec_str = debugger_receive_buffer.pop(0)
        if rec_str == 'b':continue
    return True

def debugger_send( s_text ):
    debugger_send_buffer.append( s_text )
#    wait_until_send_timing()
#    send_main()

def debugger_receive():
    if len( debugger_receive_buffer ) == 0 :
        return ''
    else :
        return debugger_receive_buffer.pop(0)

def wait_until_send_timing():
    while True :
        PICO_timer.main()
        if PICO_timer.send_timing_flag : break
    return

def wait_until_receive_response():
    global r_data
    global receive_b_flag
    PICO_timer.sub_sec_loop_count = 0
    while True :
        PICO_timer.main()
        send_main()
        receive_main()
        if PICO_timer.sub_sec_loop_count > 50 :
            print('wait_loop error')
            break
        if receive_b_flag : break
    receive_b_flag = False
    return
