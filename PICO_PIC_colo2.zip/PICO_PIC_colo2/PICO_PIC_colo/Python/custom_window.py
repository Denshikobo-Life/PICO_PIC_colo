#!/usr/bin/env python
#-*-:utf-8

import PySimpleGUI as sg
import PICO_PIC_colo_comm as comm
import datetime

window_flag = False
window = None
sec_flag = False
sub_sec_flag = False

def create_window():
    global custom_flag
    global window
    layout =  [
                [sg.Text('User Customizable Window')],
                [ sg.Input('Input',key='-input text-')],
                [ sg.Button('Send')],
                [ sg.Input('Receive',key='-receive text-')],
                [ sg.Button('Hide Main'), sg.Button('Show Main')],
                [sg.Button('Quit')]
              ]
    window = sg.Window('CUSTOM', layout,keep_on_top=True,size=(250, 250),finalize=True)
    window.hide()
    window_flag = False

def convert_hex2int( str ):
    val = int(str[2]+str[3]+str[0]+str[1],16)
    if val>=32768:
        val -=65535
    return val

def window_operation():
    global window_flag

    global sec_flag
    global sub_sec_flag
    event, values = window.read(timeout = 0)
    if event == 'Send':
        input_str = window['-input text-'].get()
        comm.user_send( input_str )
        comm.wait_until_user_response()
        receive_str = comm.user_receive()
        window['-receive text-'].update(receive_str)
    return event

def show_window():
    global window_flag
    window.UnHide()
    window_flag = True

def open_close():
    global window_flag
    if window_flag:
        window.Hide()
        window_flag = False
    else:
        show_window()
