// i2c_scanner 
#include <stdio.h>
#include <string.h>
#include "pico/stdlib.h"
#include "pico/binary_info.h"
#include "hardware/i2c.h"
#include "ring_buffer.h"
#include "check_point.h"

void put_ring_buff_byte ( struct RING_BUFF *ring_buff, uint8_t byte );
void set_user_send_request(void);
extern bool user_rec_ready_flag;
extern bool user_send_request_flag;

#define BUFF_SIZE 2100
struct RING_BUFF user_receive_ring_buff;   // extern reference in uart.c
char user_receive_buff[BUFF_SIZE];
struct RING_BUFF user_send_ring_buff;  // extern reference in uart.c
char user_send_buff[BUFF_SIZE];

void start_user_operation(void);  // define in this file
void set_user_send_request(void);
extern bool sec_flag;
void uart_set_user_request(void); 

uint8_t addr;

// call from main_init() @PICO_Pic_colo.c
void custom_init(void)
{
    init_ring_buff( &user_receive_ring_buff, user_receive_buff, BUFF_SIZE );
    init_ring_buff( &user_send_ring_buff, user_send_buff,BUFF_SIZE );

    // cp examples
    set_cp_pass(0);  // Set Pass mode
    set_cp_pass(1);  // Set Auto( release)
    set_cp_pass(2);
    set_cp_pass(3);
    set_cp_pass(4);
    set_cp_pass(5);  // Set Hold mode

    set_cp_sub_sec_clear(0);  // Set sub_sec_clear mode at cp_0
    set_cp_manual_clear(1);   // Set manual_clear_mode at cp_1
    set_cp_manual_clear(2);
    set_cp_manual_clear(3);
    set_cp_manual_clear(4);
    set_cp_manual_clear(5);

    i2c_init(i2c_default, 100 * 1000);
    gpio_set_function(PICO_DEFAULT_I2C_SDA_PIN, GPIO_FUNC_I2C);
    gpio_set_function(PICO_DEFAULT_I2C_SCL_PIN, GPIO_FUNC_I2C);
    gpio_pull_up(PICO_DEFAULT_I2C_SDA_PIN);
    gpio_pull_up(PICO_DEFAULT_I2C_SCL_PIN);
    bi_decl(bi_2pins_with_func(PICO_DEFAULT_I2C_SDA_PIN, PICO_DEFAULT_I2C_SCL_PIN, GPIO_FUNC_I2C));
    addr = 0;
}

// I2C reserves some addresses for special purposes. We exclude these from the scan.
// These are any addresses of the form 000 0xxx or 111 1xxx
bool reserved_addr(uint8_t addr) {
    return (addr & 0x78) == 0 || (addr & 0x78) == 0x78;
}

// call from uart send/receive loop
// short means less than 50us
void custom_short_ope(void)
{

    return;
}

void put_ring_buff_string( char *str, uint8_t len)
{
    uint8_t loop;

    for( loop = 0; loop<(len-1);loop++ )
    {
        put_ring_buff( &user_send_ring_buff, *(str+loop));
    }
}

// call from main_loop() @PICO_Pic_colo.c
// so, call is stop when uart send/receive looping

void custom_main() {
    char c;
    int ret;
    uint8_t loop;
    uint8_t rxdata;
    uint8_t addr;
    char send_str[] = "Reslt:";

    check_point(0);
    custom_short_ope();

    if( user_rec_ready_flag )
    {
        while( user_receive_ring_buff.flag == BUFF_NOT_EMPTY )
        {
            c = get_ring_buff( &user_receive_ring_buff );
        }

        put_ring_buff_string( send_str ,sizeof(send_str) );

        for (addr = 0; addr < 128; addr++) {
            // Skip over any reserved addresses.
            if (reserved_addr(addr))
            {
                ret = PICO_ERROR_GENERIC;
            }
            else
            {
                ret = i2c_read_timeout_us(i2c0, addr, &rxdata, 1, false, 10000 );
                if( ret >= 0)
                {
                    put_ring_buff_byte( &user_send_ring_buff, addr);
                    put_ring_buff( &user_send_ring_buff, ' ');
                }
            }
        }
        user_send_request_flag = true;
        user_rec_ready_flag = false;
        check_point(1);
        check_point(2);
        check_point(3);
        check_point(4);
        check_point(5);
    }
}

