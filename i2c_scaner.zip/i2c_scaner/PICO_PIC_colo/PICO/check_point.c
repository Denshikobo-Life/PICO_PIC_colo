/*
 * Copyright (c) 2021 Denshikobo-Life Ltd.
 *
 * License-Identifier: MIT
 */

#include <stdio.h>
#include "pico/stdlib.h"
#include "check_point.h"

uint16_t pass_count[16];
uint8_t hold_mode[16];        // 0:pass 1:hold 2:auto reset
uint8_t clear_count_mode[16]; // 0:clear per sec 1:clear per sub_sec 2:manual clear
uint8_t break_point_num;
bool release;
uint16_t hold_pass_count[16];
bool manual_clear;

#define PASS_MODE 0
#define HOLD_MODE 1
#define AUTO_MODE 2

#define SUB_SEC_CLEAR_MODE 0
#define SEC_CLEAR_MODE 1
#define MANUAL_CLEAR_MODE 2

uint16_t auto_loop_count;
uint16_t auto_release_count;
uint16_t pass_clear_count;
uint16_t break_point_timer;
uint16_t break_loop_count;
uint16_t break_sub_sec_count;
bool hold_flag;

extern bool sec_flag;
extern bool sub_sec_flag;
extern bool send_bp_flag;
extern uint16_t sub_sec_count;

void clear_pass_count(void)
{
    uint8_t loop;
    for (loop = 0; loop < 16; loop++)
    {
        if ((sub_sec_flag) && (clear_count_mode[loop] == SUB_SEC_CLEAR_MODE))
        {
            hold_pass_count[loop] = pass_count[loop];
            pass_count[loop] = 0;
        }
        else if ((sec_flag) && (clear_count_mode[loop] == SEC_CLEAR_MODE))
        {
            hold_pass_count[loop] = pass_count[loop];
            pass_count[loop] = 0;
        }
        else if ((manual_clear) && (clear_count_mode[loop] == MANUAL_CLEAR_MODE))
        {
            hold_pass_count[loop] = 0;
            pass_count[loop] = 0;
        }
    }
    manual_clear = false;
}

void clear_hold_pass_count(void)
{
    uint8_t loop;
    for (loop = 0; loop < 16; loop++)
    {
        hold_pass_count[loop] = 0;
    }
}

void reset_check_point(void)
{
    uint8_t loop;

    for (loop = 0; loop < 16; loop++)
    {
        pass_count[loop] = 0;
        hold_mode[loop] = PASS_MODE;
        clear_count_mode[loop] = SUB_SEC_CLEAR_MODE;
    }
    break_point_num = 16;
    release = false;
    pass_clear_count = 10;
}

void command_response_main(void);
void ms_timer(void);
void uart_send_loop(void);
void uart_receive_loop(void);

extern uint16_t sub_ms_count;

void set_cp_auto(uint8_t cp)
{
    hold_mode[cp] = AUTO_MODE;
}

void set_cp_hold(uint8_t cp)
{
    hold_mode[cp] = HOLD_MODE;
}

void set_cp_pass(uint8_t cp)
{
    hold_mode[cp] = PASS_MODE;
}

void set_cp_sub_sec_clear(uint8_t cp)
{
    clear_count_mode[cp] = SUB_SEC_CLEAR_MODE;
}

void set_cp_sec_clear(uint8_t cp)
{
    clear_count_mode[cp] = SEC_CLEAR_MODE;
}

void set_cp_manual_clear(uint8_t cp)
{
    clear_count_mode[cp] = MANUAL_CLEAR_MODE;
}


extern char debug_dump1[20];

void push_dump( char *buff, char c );

void break_point(uint8_t bp)
{
    pass_count[bp]++;
    if (pass_count[bp] >= 60000)
    {
        pass_count[bp] = 60000;
    }

    if (clear_count_mode[bp] == MANUAL_CLEAR_MODE)
    {
        hold_pass_count[bp] = pass_count[bp];
    }

    if (sub_sec_flag)
    {
        clear_pass_count();
    }

    if (hold_mode[bp] == PASS_MODE)
        return;
    hold_flag = true;
    break_point_num = bp;
    if (hold_mode[bp] == AUTO_MODE)
    {
        auto_loop_count = 0;
        hold_flag = true;
        while ((auto_loop_count < auto_release_count) || (!send_bp_flag))
        {
            ms_timer();
            if (sub_sec_flag)
                auto_loop_count++;
            uart_send_loop();
            uart_receive_loop();
            command_response_main();
            if (!hold_flag)
                break;
        }
        send_bp_flag = false;
    }
    else if (hold_mode[bp] == HOLD_MODE)
    {
        while ((hold_flag) && (hold_mode[bp] == HOLD_MODE))
        {
            ms_timer();
            uart_send_loop();
            uart_receive_loop();
            command_response_main();
        }
    }
    break_point_num = 16;
}

void check_point(uint8_t cp)
{
    break_point(cp);
}

void release_break(void)
{
    hold_flag = false;
}

void clear_manual_pass_count(void)
{
    manual_clear = true;
}
