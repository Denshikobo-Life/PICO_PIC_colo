/*
 * Copyright (c) 2021 Denshikobo-Life Ltd.
 *
 * License-Identifier: MIT
 */

#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/uart.h"
#include "hardware/irq.h"
#include "ring_buffer.h"

#define BAUD_RATE 115200
#define DATA_BITS 8
#define STOP_BITS 1
#define PARITY    UART_PARITY_NONE

enum rec_mode {
  REC_IDLE,
  REC_DEBUG,
  REC_USER,
  REC_REQUEST,
  REC_RESET
};

enum rec_mode uart_rec_mode;

bool command_send_request_flag;
bool user_send_request_flag;

bool command_rec_ready_flag;
bool user_rec_ready_flag;
bool receive_request_flag;
bool reset_request_flag;

#define BUFF_SIZE 2100
struct RING_BUFF uart_send_ring_buff;
char uart_send_buff[BUFF_SIZE];
struct RING_BUFF uart_receive_ring_buff;
char uart_receive_buff[BUFF_SIZE];

extern struct RING_BUFF command_receive_ring_buff;
extern struct RING_BUFF command_send_ring_buff;
extern struct RING_BUFF user_receive_ring_buff;
extern struct RING_BUFF user_send_ring_buff;

char debug_dump1[20];
char debug_dump2[20];
char debug_dump3[20];
uint debug_size;

char save_debug_dump1[20];
char save_debug_dump2[20];
char save_debug_dump3[20];
uint save_debug_size;

void push_dump( char *buff, char c )
{
    uint8_t posi;
    char s;

    for( posi=0;posi<20;posi++ )
    {
        s = buff[posi];
        buff[posi] = c;
        c = s;
    }
}


void save_dump( void)
{
    uint8_t posi;
    char c;
    for( posi=0;posi<20;posi++ )
    {
        c = debug_dump1[posi];
        save_debug_dump1[posi] = c;
        c = debug_dump2[posi];
        save_debug_dump2[posi] = c;
        c = debug_dump3[posi];
        save_debug_dump3[posi] = c;
    }
    save_debug_size = debug_size;
}

void break_point( uint8_t bp );

void setup_uart(void)
{
    init_ring_buff( &uart_receive_ring_buff, uart_receive_buff, BUFF_SIZE );
    init_ring_buff( &uart_send_ring_buff, uart_send_buff,BUFF_SIZE );

    uart_rec_mode = REC_IDLE;

    command_send_request_flag = false;
    user_send_request_flag = false;
    command_rec_ready_flag = false;
    user_rec_ready_flag = false;
    receive_request_flag = false;
    reset_request_flag = true;
}

extern int pattern;
bool first_time = true;

void receive_char( void )
{
int r;
    r = getchar();
    put_ring_buff( &uart_receive_ring_buff, (char)r );
}

void send_char( char c )
{
    putchar( c );
}

void message_send( char c1, char c2 )
{
    put_ring_buff( &uart_send_ring_buff, (char)0x03);
    put_ring_buff( &uart_send_ring_buff, c1);
    put_ring_buff( &uart_send_ring_buff, c2);
    put_ring_buff( &uart_send_ring_buff, (char)0x00);
}

void message_out( char c1, char c2 )
{
    send_char( (char)0x03 );
    send_char( c1 );
    send_char( c2 );
    send_char( (char)0x00 );
}

char convert_char( uint8_t h )
{
    if( h <= 9)return h+0x30;
    else return h - 10 + 'A';
}

void message_dump_hex( uint16_t d )
{
    uint8_t h;
    char c;
    send_char( (char)0x03 );

    h = (d>>12)&0x0f;
    c = convert_char( h );
    send_char( c );
    h = (d>>8)&0x0f;
    c = convert_char( h );
    send_char( c );
    h = (d>>4)&0x0f;
    c = convert_char( h );
    send_char( c );
    h = d&0x0f;
    c = convert_char( h );
    send_char( c );
    send_char( (char)0x00 );
}

void message_dump_buff( char *pointer )
{
    uint8_t loop;
    send_char( (char)0x03 );

    for( loop=0;loop<8;loop++)
      send_char( *pointer++ );
    send_char( (char)0x00 );
}

void uart_set_debugger_request(void) 
{
    char c;

    if( command_send_request_flag )
    {
        while( ( command_send_ring_buff.flag != BUFF_EMPTY )
            && ( uart_send_ring_buff.flag != BUFF_FULL) )
        {
            c = get_ring_buff( &command_send_ring_buff );
            put_ring_buff( &uart_send_ring_buff, c);
        }

        if(command_send_ring_buff.flag == BUFF_EMPTY)
        {
            command_send_request_flag = false;
        }
    }
}

void uart_set_user_request(void) 
{
    char c;
    if( user_send_request_flag )
    {
        while( ( user_send_ring_buff.flag != BUFF_EMPTY )
            && ( uart_send_ring_buff.flag != BUFF_FULL) )
        {
            c = get_ring_buff( &user_send_ring_buff );
            put_ring_buff( &uart_send_ring_buff, c);
        }

        if(user_send_ring_buff.flag == BUFF_EMPTY)
        {
            user_send_request_flag = false;
        }
    }
}

extern bool sec_flag;
void custom_short_ope(void);
uint8_t send_loop_mode = 0;

// 0:idle 1:send user 2:send debugger

void uart_send_loop(void)
{
    char c;


    if( send_loop_mode == 0)
    {
        if( user_send_request_flag )
        {
            put_ring_buff( &uart_send_ring_buff, 0x02);
            send_loop_mode = 1;
        }
        else if( command_send_request_flag )
        {
            send_loop_mode = 2;
        }
    }

    if( send_loop_mode == 1 )
    {
        uart_set_user_request();
        if( !user_send_request_flag )
        {
            put_ring_buff( &uart_send_ring_buff, 0x00);
            send_loop_mode = 0;
        }
    }
    else if( send_loop_mode == 2 )
    {
        uart_set_debugger_request();
        if( !command_send_request_flag )
        {
            send_loop_mode = 0;
        }
    }

    while( uart_send_ring_buff.flag != BUFF_EMPTY )
    {
        c = get_ring_buff( &uart_send_ring_buff );
        send_char( c );
        custom_short_ope();
    }
}

bool repeat_receive_flag = false;
extern bool receive_timing_flag;
void set_receive_time(void);
void ticktimer(uint8_t n);
extern int pattern;

uint8_t  reset_count;
void uart_receive_loop(void) 
{
    char c;

    if( ( !repeat_receive_flag )&&( !receive_timing_flag )) return;

    if( receive_timing_flag )
    {
        receive_timing_flag = false;
    }

    while( true )
    {
        c = getchar();
        switch( uart_rec_mode )
        {
        case REC_IDLE:
            if( c == 0x01 )
            {
                uart_rec_mode = REC_DEBUG;
                put_ring_buff( &command_receive_ring_buff, c);
            }
            else if( c == 0x02 )
            {
                uart_rec_mode = REC_USER;
//                put_ring_buff( &user_receive_ring_buff, c);
            }
            else if( c == 0x03 )
            {
                uart_rec_mode = REC_REQUEST;
                repeat_receive_flag = true;
                save_dump();
            }
            else if( c == 0x04 )
            {
                uart_rec_mode = REC_RESET;
                repeat_receive_flag = true;
            }
            break;
        case REC_DEBUG:
            put_ring_buff( &command_receive_ring_buff, c);
            if( c == 0x00 )
            {
                command_rec_ready_flag = true;
                uart_rec_mode = REC_IDLE;
            }
            break;
        case REC_USER:
            if( c == 0x00 )
            {
                user_rec_ready_flag = true;
                uart_rec_mode = REC_IDLE;
            }
            else
            {
                put_ring_buff( &user_receive_ring_buff, c);
            }
            break;
        case REC_REQUEST:
            if( c == 0x00 )
            {
                receive_request_flag = true;
                uart_rec_mode = REC_IDLE;
            }
            break;
        case REC_RESET:
            if( c == 0x00 )
            {
                receive_request_flag = false;
                reset_request_flag = true;
                uart_rec_mode = REC_IDLE;
                repeat_receive_flag = false;
                set_receive_time();
            }
            break;
        default:
            break;
        }

        custom_short_ope();

        if( reset_request_flag) 
        {
            reset_count++;
            if( reset_count >= 10 )
            {
                pattern = 2;
                reset_count = 0;
            }
            break;
        }
    }
}
