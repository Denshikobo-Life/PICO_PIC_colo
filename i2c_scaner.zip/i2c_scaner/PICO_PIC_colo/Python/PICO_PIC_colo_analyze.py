#!/usr/bin/env python
#-*-:utf-8

import os
import subprocess

def analyze_map( file_path ):
    res=[]
    if os.path.isfile( file_path ):
        cmd = "readelf -s "+file_path
        o = subprocess.check_output( cmd.split() )
        readelf_s = o.decode().strip().split('\n')
        for each_s in readelf_s:
            s_list = each_s.split()
            if len(s_list) == 8 :
                if s_list[3] == 'OBJECT' and s_list[4] == 'GLOBAL':
#                    res.append( [ s_list[1],s_list[2],s_list[7] ]) 
                    res.append( [ s_list[7],s_list[1],s_list[2] ]) 
    return res


