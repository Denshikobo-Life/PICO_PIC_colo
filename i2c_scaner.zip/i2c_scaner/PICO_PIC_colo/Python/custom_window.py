#!/usr/bin/env python
#-*-:utf-8

import PySimpleGUI as sg
import PICO_PIC_colo_comm as comm

window_flag = False
window = None

hide_main_window = True
#hide_main_window = False

def create_window():
    global custom_flag
    global window
    layout =  [
                [sg.Text('<<I2C_SCANNER>>')],
                [ sg.Input('I2C_SCANNER',key='-input text-')],
                [ sg.Button('SCAN')],
                [ sg.Input('Receive',key='-receive text-')],
                [ sg.Button('Hide Main'), sg.Button('Show Main')],
                [sg.Button('Quit')]
              ]
    window = sg.Window('Custom', layout,keep_on_top=True,size=(250, 250),finalize=True)
    show_window()
#    hide_window()

def window_operation():
    global window_flag
    event, values = window.read(timeout = 0)

    if event == 'SCAN':
        input_str = window['-input text-'].get()
        comm.user_send( input_str)
        comm.wait_until_user_response()
        receive_str = comm.user_receive()
        window['-receive text-'].update(receive_str)
    elif event == 'Quit':
        window.Hide()
        window_flag = False
    return event

def show_window():
    global window_flag
    window.UnHide()
    window_flag = True

def hide_window():
    global window_flag
    if window_flag:
        window.Hide()
        window_flag = False

def open_close():
    global window_flag
    if window_flag:
        hide_window()
    else:
        show_window()
